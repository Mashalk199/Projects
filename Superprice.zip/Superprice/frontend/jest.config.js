module.exports = {
    preset: 'ts-jest',
    testEnvironment: 'jest-environment-jsdom',
    "moduleNameMapper": {
      "\\.(css|less|scss|sss|styl)$": "jest-css-modules"
    }
    // You can add other configurations like `testMatch` if you want to specify the test files pattern
  };
  