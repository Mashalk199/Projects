import React, { useContext, useEffect, useState } from 'react';
import { Navbar, Nav, NavDropdown, Container } from 'react-bootstrap';
import { getAllCategories } from '../../axios/AxiosCommands';
import { CartContext } from '../../Contexts/ShoppingCartContext';
import { NavbarContext } from '../../Contexts/NavBarContext';
import Cart from '../../partials/ShoppingCart/Cart';
import Signup from '../../partials/Registration/Singin';
import { userContext } from '../../Contexts/UserContext';

import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { ProductContext } from '../../Contexts/ProductContext';
import useProductNotification from '../../partials/Notifications/useNotifications';
import { productType } from '../../../types/AxiosTypes';
import { useNavigate } from 'react-router-dom';

export default function CustomNavbar() {

    const [categories, setCategories] = useState([]);
    const {cartState, cartDispatch } = useContext(CartContext);
    const {state} = useContext(ProductContext)
    const {navBarState, navBarDispatch } = useContext(NavbarContext);
    const {user, setUser} = useContext(userContext);

    const navigate = useNavigate();

    // Fetches categories.
    useEffect(() => {
        async function getCategories() {
            const categoryList = await getAllCategories();
            setCategories(categoryList);
        }
        getCategories();
    }, []);
    // Triggers notifications for product updates.

    useProductNotification(state.productsList as productType[]);

    // Handle user logout
    function handleLogout(){
        setUser(null);
        localStorage.removeItem('token');
    }

    return (
        <div>
            <Navbar data-testid="navbar" collapseOnSelect expand="lg" className="bg-body-tertiary">
                <Container>
                    <Navbar.Brand>SuperPrice Shopping</Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="me-auto">
                            <Nav.Link href = {'/'}>Search & Buy</Nav.Link>
                            <NavDropdown title="Categories" id="collapsible-nav-dropdown">
                                {categories.map((category, index) => (
                                    <NavDropdown.Item key={index} href={`/ProductsPage/${category}`}>
                                        {category}
                                    </NavDropdown.Item>
                                ))}
                            </NavDropdown>
                        </Nav>
                        <Nav>
                            <Nav.Link onClick={() => {cartDispatch({type: 'toggleVisibility', payload: true})}}>
                              Your Cart ({cartState.cart.length})
                            </Nav.Link>

                            {user && user !==null ?

                                <div className='d-flex'>
                                    <Nav.Link> Welcome {user.firstName}</Nav.Link>
                                    <Nav.Link onClick={() => navigate(`/user/${user.userId}/orders`)}>Your Past Orders</Nav.Link>
                                    <Nav.Link onClick = {handleLogout}>Logout</Nav.Link>
                                </div>

                            :
                                <Nav.Link onClick={() => {navBarDispatch({type:"SHOW_SIGNUP"})}}>
                                Sign Up or Log In
                                </Nav.Link>

                            }

                        </Nav>
                    </Navbar.Collapse>
                </Container>
            </Navbar>

            <ToastContainer />


            {cartState.cartVisible && <Cart />}
            {navBarState.isSignupVisible && <Signup />}

        </div>
    );


}
