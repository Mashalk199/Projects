import React from 'react';
import { Navbar, Container } from 'react-bootstrap';

const Footer = () => {
    return (
        <Navbar fixed="bottom" bg="dark" variant="dark" style={{ padding: '0px 0'}}>
            <Container className="text-center">
                <Navbar.Text>
                    SuperPrice Application - Developed by: Group P1-02 (Ethan Makiri, Parth Kulkarni, Natnael Gizaw, Mashal Khan, Christopher Lamb and Xiaoyu Zhu) &copy; 2023

                </Navbar.Text>
            </Container>
        </Navbar>
    );
}

export default Footer;