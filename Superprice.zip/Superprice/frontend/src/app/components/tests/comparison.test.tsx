/* eslint-disable testing-library/prefer-screen-queries */
import React from 'react';
import { render } from '@testing-library/react';
import { ProductsContextProvider, ProductContext } from '../Contexts/ProductContext';
import { getSubCategories } from '../axios/AxiosCommands';
import ProductComparison from '../partials/ProductItem/ProductComparison';
import { productType } from '../../types/AxiosTypes';
import { BrowserRouter as Router } from 'react-router-dom';


jest.mock('../axios/AxiosCommands');

const mockGetSubCategories = getSubCategories as jest.MockedFunction<typeof getSubCategories>;


describe("ProductComparison component", () => {
    
    beforeEach(() => {
        jest.clearAllMocks();
    });

    it("should order similarProductList based on product id", async () => {
        // Arrange
        const mockData: productType[] = [
            { id: 3, name: "Product C", price: 50, productCategory: "test", subCategory: "TestCategory", productGroup: "GroupA", productDescription: "DescC", productImage: "imgC", supermarket: { supermarketId: 1, name: "Supermarket1", location: "Location1", postCode: "1111" } },
            { id: 1, name: "Product A", price: 60, productCategory: "test", subCategory: "TestCategory", productGroup: "GroupB", productDescription: "DescA", productImage: "imgA", supermarket: { supermarketId: 2, name: "Supermarket2", location: "Location2", postCode: "2222" } },
            { id: 2, name: "Product B", price: 70, productCategory: "test", subCategory: "TestCategory", productGroup: "GroupC", productDescription: "DescB", productImage: "imgB", supermarket: { supermarketId: 3, name: "Supermarket3", location: "Location3", postCode: "3333" } }
        ];
        mockGetSubCategories.mockResolvedValueOnce(mockData);
        
        // Act
        const { findAllByText } = render(
            <Router>
                <ProductsContextProvider>
                    <ProductComparison />
                </ProductsContextProvider>
            </Router>
            );

        // Find all products (this will give us an array of product elements)
        const products = await findAllByText(/Product/);
        expect(products).toHaveLength(3);

        // Assert
        // Check that the products are ordered by ID
        expect(products[0].textContent).toBe("Product A");
        expect(products[1].textContent).toBe("Product B");
        expect(products[2].textContent).toBe("Product C");
    });
});
