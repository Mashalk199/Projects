import axios from 'axios';
import { getAllCategories, getAllProducts } from '../axios/AxiosCommands';
import { productType, supermarketType } from '../../types/AxiosTypes';

jest.mock('axios');

const mockedAxios = axios as jest.Mocked<typeof axios>;


describe('getAllProducts', () => {
    
    it('fetches successfully data from an API', async () => {

      const freshFoods: supermarketType = {
          supermarketId: 1,
          name: 'Fresh Foods',
          location: 'Tarneit',
          postCode: '3029'
      }

      const data: productType[] = [
        {
          id: 1,
          name: "Red Apples", 
          price: 1.2, 
          productCategory: "Fruits", 
          subCategory: 'apples',
          productGroup: 'red',
          productDescription: 'Red and delicious apples', 
          productImage: 'photo-1542838132-92c53300491e_hwso6x',
          supermarket: freshFoods
        }
      ];
  
      mockedAxios.get.mockResolvedValue({ data });
  
      const result = await getAllProducts();
      expect(result).toEqual(data);
    });
  
    it('fetches erroneously data from an API', async () => {
      const errorMessage = 'Error fetching data';
  
      mockedAxios.get.mockRejectedValue(new Error(errorMessage));
  
      await expect(getAllProducts()).rejects.toThrow(errorMessage);
    });


describe('getAllCategories', () => {

  it('fetches all the category names from the API', async () => {

    const data: string[] = ['Grains', 'Meat'] 

    mockedAxios.get.mockResolvedValue({ data });
  
    const result = await getAllCategories();
    expect(result).toEqual(data);

  })

})

});
  