import { render, screen, fireEvent } from '@testing-library/react';
import React from 'react';
import Signup from '../partials/Registration/Signup';
import '@testing-library/jest-dom'
import { BrowserRouter } from 'react-router-dom';

describe('Signup Component', () => {

  beforeEach(() => {
    // eslint-disable-next-line testing-library/no-render-in-setup
    render(
    <BrowserRouter>
    <Signup />
    </BrowserRouter>);
  });

  test('should render all input fields', () => {
    // Check for all the fields by their test IDs
    const emailInput = screen.getByTestId('email');
    const passwordInput = screen.getByTestId('password');
    const firstNameInput = screen.getByTestId('firstName');
    const lastNameInput = screen.getByTestId('lastName');
    const streetNameInput = screen.getByTestId('streetName');
    const cityNameInput = screen.getByTestId('cityName');
    const postCodeInput = screen.getByTestId('postCode');
    const suburbCodeInput = screen.getByTestId('suburbCode');

    expect(emailInput).toBeInTheDocument();
    expect(passwordInput).toBeInTheDocument();
    expect(firstNameInput).toBeInTheDocument();
    expect(lastNameInput).toBeInTheDocument();
    expect(streetNameInput).toBeInTheDocument();
    expect(cityNameInput).toBeInTheDocument();
    expect(postCodeInput).toBeInTheDocument();
    expect(suburbCodeInput).toBeInTheDocument();
  });

  
  test('should show error validations when submit button is clicked with invalid data', async () => {
    // Click the submit button without filling any inputs
    const submitButton = screen.getByText('Submit');
    fireEvent.click(submitButton);

    // Wait for errors to appear
    const emailError = await screen.findByText('Email not provided!');
    const firstNameError = await screen.findByText('First name not provided!');
    const lastNameError = await screen.findByText('Last name not provided!');
    const passwordError = await screen.findByText('Password not provided!');
    const streetError = await screen.findByText('Street not provided!');
    const cityError = await screen.findByText('City not provided!');
    const postalCodeError = await screen.findByText('Postal code not provided!');
    const suburbError = await screen.findByText('Suburb not provided!');

    expect(emailError).toBeInTheDocument();
    expect(firstNameError).toBeInTheDocument();
    expect(lastNameError).toBeInTheDocument();
    expect(passwordError).toBeInTheDocument();
    expect(streetError).toBeInTheDocument();
    expect(cityError).toBeInTheDocument();
    expect(postalCodeError).toBeInTheDocument();
    expect(suburbError).toBeInTheDocument();
  });

  
});