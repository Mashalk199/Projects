/* eslint-disable testing-library/prefer-screen-queries */
// Navbar.test.tsx
import { BrowserRouter } from 'react-router-dom';
import { render } from '@testing-library/react';
import '@testing-library/jest-dom'; // for the "toBeInTheDocument" matcher
import CustomNavbar from '../layouts/Navbar/Navbar';

describe('Navbar', () => {
  it('renders correctly', () => {
    const { getByTestId } = render(
      <BrowserRouter>
        <CustomNavbar />
      </BrowserRouter>
    );
    const navbarElement = getByTestId('navbar');
    expect(navbarElement).toBeInTheDocument();
  });
});
