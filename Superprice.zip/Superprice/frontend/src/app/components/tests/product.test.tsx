import { productsReducer } from "../Reducers/productsReducer";
import { CurrentAction, CurrentState } from "../Contexts/ProductContext";
import axios from 'axios';
import { getSubCategories } from '../axios/AxiosCommands';


// User search testing

describe('productsReducer', () => {
  let initialState: CurrentState;

  beforeEach(() => {
    initialState = {
      searchContent: "",
      selectedCategory: "",
      productsList: null,
      updatedProductsList: null,
      individualSelectedProduct: null,
      similarProductList: null, 
      productReviews: null
    };
  });

  it('should set products correctly', () => {

    const action: CurrentAction = {
        type: 'setProducts',
        payload: [
            {
                id: 1,
                name: 'Test Product',
                price: 99.99,
                productCategory: 'Test Category',
                subCategory: 'Test SubCategory',
                productGroup: 'Test Group',
                productDescription: 'This is a test product',
                productImage: 'test-image-url.jpg',
                supermarket: {
                    supermarketId: 1,
                    name: 'Test Supermarket',
                    location: 'Test Location',
                    postCode: '12345'
                }
            }
        ]
    };
    
    const newState = productsReducer(initialState, action);

    expect(newState.productsList).toEqual(action.payload);
  });

  it('should update search content and updatedProductsList', () => {
    
    initialState.productsList = [
      {
        id: 1,
        name: 'apple',
        price: 0.99,
        productCategory: 'Fruits',
        subCategory: 'Test SubCategory',
        productGroup: 'Test Group',
        productDescription: 'This is a test product',
        productImage: 'apple-image-url.jpg',
        supermarket: {
          supermarketId: 1,
          name: 'Test Supermarket',
          location: 'Test Location',
          postCode: '12345'
        }
      },
      {
        id: 2,
        name: 'orange',
        price: 0.89,
        productCategory: 'Fruits',
        subCategory: 'Test SubCategory',
        productGroup: 'Test Group',
        productDescription: 'This is another test product',
        productImage: 'orange-image-url.jpg',
        supermarket: {
          supermarketId: 1,
          name: 'Test Supermarket',
          location: 'Test Location',
          postCode: '12345'
        }
      }
    ];

    const action: CurrentAction = {
        type: 'searchUpdate',
        payload: 'apple'
    };
    
    const newState = productsReducer(initialState, action);

    expect(newState.searchContent).toEqual('apple');
    expect(newState.updatedProductsList).toEqual([initialState.productsList[0]]);
  });

});


