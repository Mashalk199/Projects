import axios from 'axios'

import { AuthUser, LoginUserType, Orders, ProductReview, TimeSlotsDataType, UserForm, productReviewSubmit, productType } from '../../types/AxiosTypes'
import {User} from '../../types/AxiosTypes'

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8080';

// Product Service API Endpoints
export async function getAllProducts() {
    const { data } = await axios.get<productType[]>(`${API_URL}/api/product/all`);
    return data;
}
// Fetch a product by its ID
export async function getProduct(id: string){
    const {data} = await axios.get<productType>(`${API_URL}/api/product/${id}`);
    return data;
}
// Fetch similar products based on category
export async function getSimilarProducts(category: string){
    const {data} = await axios.get<productType[]>(`${API_URL}/api/product/byCategory/${category}`);
    return data;
}
// Fetch all product categories
export async function getAllCategories() {
    const { data } = await axios.get<[]>(`${API_URL}/api/product/allCategories`);
    return data;
}
// Fetch products based on sub-category
export async function getSubCategories(subCategory: string){
    const {data} = await axios.get<productType[]>(`${API_URL}/api/product/bySubCategory/${subCategory}`);
    return data;
}

// Supermarket Service API Endpoints
export async function getSupermarketById(id: string) {
    const {data} = await axios.get<productType[]>(`${API_URL}/api/supermarket/byCategory/${id}`);
    return data;
}

export async function createUser(user: UserForm){
    const data = await axios.post<AuthUser>(`${API_URL}/api/users/create`, user);
    return data;
}
// Log in a user
export async function loginUser(user: LoginUserType){

    const data = await axios.post<AuthUser>(`${API_URL}/api/users/login`, user)

    console.log(data, 'axios return loginUser')

    return data


}

export async function verifyUser(token: string){
    const data = await axios.get<User>(`${API_URL}/api/users/verify`, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return data;
}
// Fetch all checkout schedules
export async function getAllCheckoutSchedule(){
    const {data} = await axios.get<TimeSlotsDataType>(`${API_URL}/api/checkout/schedules`, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return data;
}
// Saves an order to the database
export async function saveOrderToDatabase(orderData: any){
    const data = await axios.post(`${API_URL}/api/orders`, orderData, {
        headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
        }
    });
    return data;
}

export async function getProductReviews(productId: number){
    const data = await axios.get<ProductReview[]>(`${API_URL}/api/review/${productId}/reviews`)

    return data

}

// Used to save review
export async function saveReview(reviewData: productReviewSubmit) {
    try {
        const response = await axios.post<ProductReview>(`${API_URL}/api/review`, reviewData);
        return response.data;
    } catch (error : any) {
        throw error.response || error;
    }
}

// Get users all post orders
export async function getAllUserOrders(userId: number){

    console.log(userId, "id in axios")

    try {

        const response = await axios.get<Orders[]>(`${API_URL}/api/orders/user/${userId}/orders`);

        console.log(response.data)

        return response.data;
    } catch (error : any) {
        throw error.response || error;
    }

}

