import { CartContext } from "../../Contexts/ShoppingCartContext";
import { userContext } from "../../Contexts/UserContext";
import { useContext, useEffect, useState } from "react";
import './Checkout.css'
import { getAllCheckoutSchedule, saveOrderToDatabase } from "../../axios/AxiosCommands";
import { TimeSlotsDataType, productType } from "../../../types/AxiosTypes";
import { groupCarts } from "../../../utils/GroupCart";
import { useNavigate } from "react-router-dom";

import { Button, Card } from "react-bootstrap";
import { cld } from "../../../utils/Cloudinary";
import { AdvancedImage } from '@cloudinary/react';
import { thumbnail } from "@cloudinary/url-gen/actions/resize";
// Define a type for grouped cart items
type GroupCarts = {
    item: productType, 
    quantity: number
  }
 
function Checkout() {
    // State to manage checkout-related data
    const [timeSlotsData, setTimeSlotsData] = useState<TimeSlotsDataType>([]);
    const [selectedDate, setSelectedDate] = useState<string>('');
    const [selectedTime, setSelectedTime] = useState<string>('')
    // Access cart data from context
    const {cartState, cartDispatch} = useContext(CartContext);
    const {user} = useContext(userContext);
    const totalWithGST = (cartState.currentTotal * 0.10) + cartState.currentTotal
    let groupedCarts : GroupCarts[] = groupCarts(cartState.cart);
    const navigate = useNavigate();


    const renderAddress = () => {
        if (!user) return "User information not available";

        return `${user.street}, ${user.suburb}, ${user.city}, ${user.state}, ${user.postalCode}`;
    };

    useEffect(() => {

        async function getSchedules(){
            const response = await getAllCheckoutSchedule()

            setTimeSlotsData(response);

        }

        getSchedules();

    }, []);

    const renderDates = () => {
        return timeSlotsData.map(entry => {
            const dateObject = new Date(entry.date);
            const day = dateObject.toLocaleString('default', { weekday: 'long' });
            const dateAndMonth = dateObject.toLocaleString('default', { month: 'short', day: 'numeric' });
    
            return (
                <Card 
                    className={entry.date === selectedDate ? 'selected-date card-date' : 'card-date'} 
                    key={entry.date} 
                    onClick={() => setSelectedDate(entry.date)}
                >
                    <Card.Body>
                        <Card.Title style={{ fontSize: '15px' }}>{day}</Card.Title>
                        <Card.Text>{dateAndMonth}</Card.Text>
                    </Card.Body>
                </Card>
            );
        });
    };
    
    const renderTimeSlots = () => {
        if (!selectedDate) return "Select a date to view available time slots";

        const selectedDateData = timeSlotsData.find(entry => entry.date === selectedDate);
        if (!selectedDateData) return null;

        return selectedDateData.availableTimeSlots.map(slot => (

            <div className="d-flex flex-gap-10">
                <Button 
                    key={slot} 
                    onClick={() => setSelectedTime(slot)}
                    variant="success"
                    className="time-slot">
                    {slot}
                </Button>
            </div>

        ));
    };

    const handleOrder = async () => {

        // Here we will create an order object and save that to the backend..

        if (!user) {
            alert('You are not logged in')
            navigate('/')
            return
        }

        console.log(user.userId)
        
        const orderData = {
            user: { userId: user.userId },
            totalCost: totalWithGST,
            orderProducts: cartState.cart.map(item => ({
                productId: item.id
            })),
        };

        const response = await saveOrderToDatabase(orderData);

        if(response.status === 201){
            alert('Order placed sucessfully')
            cartDispatch({type: 'removeAllItems', payload: null});

            navigate('/')
        }

        else{
            alert('Something has gone wrong...')

        }
        

    }


    return(

        <div className="d-flex p-1">

            <div className="left-container d-flex flex-column flex-gap-10 mt-5 p-3">

                <Card className="p-3" style={{ width: '56rem', textAlign: "left" }}>
                    <Card.Title><b>Delivery Location</b></Card.Title>
                    <hr></hr>

                    <Card.Body>
                        Delivery To:
                        <br></br>
                        {renderAddress()}
                    </Card.Body>

                </Card>

                <Card className="p-3" style={{ width: '56rem', textAlign: "left" }}>

                        <Card.Title className = "d-flex justify-content-between"><b>Select a time - {selectedDate} : {selectedTime}</b>
                            <Button
                                onClick={() => { setSelectedDate(''); setSelectedTime('')}}
                                variant="success"
                            >Reset Date and Time</Button>
                        </Card.Title>
                
                    <hr></hr>

                    <Card.Body>
                       
                    <div className="d-flex flex-gap-30 justify-content-evenly date-picker">
                        {renderDates()}
                    </div>

                    <hr></hr>

                    <div className="d-flex flex-column align-items-center flex-gap-10 time-slots mt-2">
                        {renderTimeSlots()}
                    </div>
                        
                    </Card.Body>

                </Card>

                <Card className = "p-3" style={{ width: '56rem', textAlign: "left" }}>
                    <Card.Title className="d-flex justify-content-between"><b>Review Your Items</b>
                        <Button
                            onClick={() => cartDispatch({type:"toggleVisibility", payload: true})}
                            variant="success"
                        >Modify my items</Button>
                    </Card.Title>
                    <hr></hr>

                    <Card.Body>

                        {groupedCarts.map(({item, quantity}, index) => (
                            <div className="d-flex flex-column mb-5 cart-item-box" key={item.id}>
                                <div className="d-flex flex-gap-20 align-items-center">
                                <AdvancedImage cldImg={cld.image(item.productImage).resize(thumbnail().width(100).height(100))}></AdvancedImage>
                                <div className="mr-5">
                                    <div>Name: {item.name}</div>
                                    <div className = "mt-20">
                                    Quantity: {quantity}
                                    </div>
                                    <div className = "mt-20">
                                    Cost: ${(quantity * item.price).toFixed(2)}
                                    </div>
                                </div>
                                
                                </div>
                            </div>

                        ))}
                        
                                
                    </Card.Body>

                </Card>


            </div>
        
            <div className="right-container mt-5 p-3">
                
                <Card style={{ width: '30rem' }}>

                    <div className="d-flex order-styling justify-content-between align-items-center">
                        <div>
                            <Card.Title style = {{textAlign: 'left'}}>Your order:</Card.Title>
                        </div>

                        <div className="mt-1">
                            <p>Total(incl.GST)</p>
                            <h5>${totalWithGST.toFixed(2)}</h5>
                        </div>
                        
                    </div>

                    <div className="mt-2 p-2">

                        <div className="d-flex justify-content-between">
                        <Card.Text><b>Subtotal</b></Card.Text>
                        <Card.Text> ${cartState.currentTotal.toFixed(2)}</Card.Text>
                        </div>

                        <div className="d-flex justify-content-between">
                            <Card.Text>Delivery fee</Card.Text>
                            <Card.Text>$15.00</Card.Text>
                        </div>

                    </div>

                    <hr></hr>

                    <div className="d-flex justify-content-between p-2">
                        <Card.Title>Total (incl.GST) </Card.Title>
                        <Card.Title>${(totalWithGST + 15.00).toFixed(2)}</Card.Title>
                    </div>


                    <Button className="mt-4" 
                            disabled = {selectedDate.length === 0 ||  selectedTime.length === 0}
                            variant= {selectedDate.length === 0 ||  selectedTime.length === 0 ? "grey" : "success"}
                            onClick={handleOrder}
                            >Place Order!</Button>


                </Card>

            </div>

        </div>
    )
}

export default Checkout;