/**
 * Validate user input for registration.
 * @param {object} user - User registration information.
 * @param {string} user.email - User's email address.
 * @param {string} user.firstName - User's first name.
 * @param {string} user.lastName - User's last name.
 * @param {string} user.password - User's password.
 * @param {string} user.street - User's street address.
 * @param {string} user.city - User's city.
 * @param {string} user.state - User's state (optional).
 * @param {string} user.postalCode - User's postal code.
 * @param {string} user.suburb - User's suburb.
 * @returns {object} - An object containing validation errors and success status.
 */
export function Validation(user: any){
    // Initialize an object to store validation errors and success status
    const ErrorsObj = {
        emailError: "",
        passwordError: "",
        firstNameError: "",
        lastNameError: "",
        streetError: "",
        cityError: "",
        stateError: "",
        postalCodeError: "",
        suburbError: "",
        validationSuccess: false
    } 

    if(user.email.length === 0){
        ErrorsObj.emailError = 'Email not provided!'
    }

    // eslint-disable-next-line no-useless-escape
    else if (user.email.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/) == null){
        ErrorsObj.emailError = 'Email Formatting is incorrect'
    }

    /*

    else{
        const results = await findUser(user.email);

        if (results !== null){
            ErrorsObj.emailError = 'This Email Already Exists'
        }
    } */


    if (user.firstName.length === 0){
        ErrorsObj.firstNameError = 'First name not provided!'
    }

    else if (user.firstName.match(/^[a-zA-Z]+$/) == null){
        ErrorsObj.firstNameError = 'First name cannot contain symbols or numbers'
    }

    if (user.lastName.length === 0){
        ErrorsObj.lastNameError = 'Last name not provided!'
    }

    else if (user.lastName.match(/^[a-zA-Z]+$/) == null){
        ErrorsObj.lastNameError = 'Last name cannot contain symbols or numbers'
    }


    if (user.password.length === 0){
        ErrorsObj.passwordError = 'Password not provided!'
    }

    else if (user.password.match(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/) ==  null){
        ErrorsObj.passwordError = 'Passwords should contain 8 to 15 characters, one uppercase letter, one numeric digit and one special character'
    }

     if (user.street.length === 0) {
        ErrorsObj.streetError = 'Street not provided!';
    }

    if (user.city.length === 0) {
        ErrorsObj.cityError = 'City not provided!';
    }

    if (user.postalCode.length === 0) {
        ErrorsObj.postalCodeError = 'Postal code not provided!';
    }

    if (user.suburb.length === 0) {
        ErrorsObj.suburbError = 'Suburb not provided!';
    }

    if (ErrorsObj.emailError === '' && ErrorsObj.passwordError === '' &&
        ErrorsObj.firstNameError === '' && ErrorsObj.lastNameError === '' &&
        ErrorsObj.streetError === '' && ErrorsObj.cityError === '' &&
        ErrorsObj.stateError === '' && ErrorsObj.postalCodeError === '' &&
        ErrorsObj.suburbError === '') {

        ErrorsObj.validationSuccess = true;
    }


     return ErrorsObj

 }
