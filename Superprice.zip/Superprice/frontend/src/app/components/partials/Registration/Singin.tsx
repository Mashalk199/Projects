import React, { useState, useContext } from "react";
import { useNavigate, Link } from "react-router-dom";
import './Signup.css';
import { NavbarContext } from "../../Contexts/NavBarContext";
import { loginUser } from "../../axios/AxiosCommands";

import {Button, Form, Offcanvas} from 'react-bootstrap';
import { userContext } from "../../Contexts/UserContext";

const userStateErrorsDefined = {
  emailError: "",
  passwordError: "",
} 


function Signin(){

  const {navBarState, navBarDispatch} = useContext(NavbarContext);
  const {user, setUser} = useContext(userContext);

  const navigate = useNavigate();

  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [errors, setErrors] = useState(userStateErrorsDefined)

  

  function handleEmail(event: React.ChangeEvent<HTMLInputElement>){
    setEmail(event.target.value);
  }

  function handlePassword(event: React.ChangeEvent<HTMLInputElement>){
    setPassword(event.target.value);
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>){
    
    // Prevents submission of Form
    event.preventDefault();
  
    if(email.length === 0 && password.length === 0){
      setErrors({emailError: "Please Provide Email", passwordError: "Please Provide Password"});
      return;
    }
  
    if(email.length === 0){
      setErrors({...errors, emailError: "Please Provide Email"});
      return;
    }
  
    if(password.length === 0){
      setErrors({...errors, passwordError: "Please Provide Password"});
      return;
    }
  
    try {
      const response = await loginUser({email: email, password: password});
  
      if(response.status === 200){
        // Login is good
        const userObj = response.data;
  
        setUser(userObj.user); // We set the user in the context
  
        localStorage.setItem('token', userObj.jwtToken);
  
        console.log(user, "context object");
    
        navigate("/"); // A dummy route
      }

    } catch (error) {
   
      setErrors({
        emailError: "Incorrect email or password provided", 
        passwordError: "Incorrect email or password provided"
      });
    }
  }


  return(
    <div>

        <Offcanvas show = {navBarState.isSignupVisible} onHide = {() => navBarDispatch({type: "HIDE_SIGNUP"})} placement="end">
          <Offcanvas.Header closeButton>
            <h3>Login or Sign Up</h3>
            <br></br>
            <hr></hr>
          </Offcanvas.Header>

          <Offcanvas.Body>
            
            <Link to={'/Signup'} data-testid="link" onClick={() => navBarDispatch({type: "HIDE_SIGNUP"})}>New To SuperPrice? Sign Up Here.</Link>

            <Form onSubmit={handleSubmit}>

              <Form.Group>
                <Form.Label>Email Address</Form.Label>
                <Form.Control data-testid="email" 
                              onChange={handleEmail} 
                              type="email" 
                              placeholder="Email address"
                              isInvalid = {!!errors.emailError}
                              isValid = {!errors.emailError && errors.emailError !== ''} 
                />

                <Form.Control.Feedback type = "invalid">{errors.emailError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>
              <Form.Group>
                <Form.Label>Password</Form.Label>
                <Form.Control data-testid="password" 
                              onChange = {handlePassword} 
                              type="password" 
                              placeholder="Password"
                              isInvalid = {!!errors.passwordError}
                              isValid = {!errors.passwordError && errors.passwordError !== ''} 
                />

                            
                <Form.Control.Feedback type = "invalid">{errors.passwordError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>

              <Button type = "submit" variant = "success">Login</Button>

            </Form>


          </Offcanvas.Body>

        </Offcanvas>

    </div>

  )



}


export default Signin;

// {validSignin()}
