import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import './Signup.css';
import {Button, Card, Form} from 'react-bootstrap';
import { Validation } from "./Validation";
import { createUser } from "../../axios/AxiosCommands";
import { userContext } from "../../Contexts/UserContext";
import {UserForm} from '../../../types/AxiosTypes'

function Signup(){

  const userStateDefined = {
    email: "",
    password: "",
    firstName: "",
    lastName: "" ,
    street: "",
    city: "",
    state: "VIC",
    postalCode: "",
    suburb: "",
    loggedIn: false,
   
} 


const userStateErrorsDefined = {
    emailError: "",
    passwordError: "",
    firstNameError: "",
    lastNameError: "",
    streetError: "",
    cityError: "",
    stateError: "",
    postalCodeError: "",
    suburbError: "",
    validationSuccess: false
} 

  const [userState, setuserState] = useState(userStateDefined);
  const [errors, setErrors] = useState(userStateErrorsDefined);
  const {setUser} = useContext(userContext);
  const navigate = useNavigate();

  
  function handleChange <P extends keyof UserForm>(prop: P, value: UserForm[P] ){

    setuserState({ ...userState, [prop]: value });
}

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>){
    
    // Prevents submission of Form
    event.preventDefault();

    const ErrorsObj = Validation(userState)

    if(ErrorsObj.validationSuccess){
        
      const response = await createUser(userState);

      console.log(response, "HEY USER LOOKS LIKE THIS")

      if (response.status === 201) {

        setUser(response.data.user)

        localStorage.setItem('token', response.data.jwtToken)

        navigate('/')          
          // Redirect or clear form
      }

      else{
        alert('Something has gone wrong')
      }
    }

    else{
      setErrors(ErrorsObj)
    }


    // Now we will validate the password and email inputs

  }

  return(

    <div className="cardContainer">
    
      <Card className="d-flex mt-5" style = {{width:'35rem', minHeight: '50rem'}}>

        <Card.Title className="mt-2"> 
        
        Let's create your account.
        
        </Card.Title>

        Already have an account? Login Here.

        <Card.Body>

            <Form onSubmit={handleSubmit}>

              <div className="d-flex flex-column">

                <div className = "d-flex">
                  <h4>Login Details</h4>
                </div>
                
                <Form.Group className = "mt-2">
                  <Form.Control 
                    onChange = {(e) => {handleChange("email", e.target.value)}}
                    isInvalid = {!!errors.emailError}
                    isValid = {!errors.emailError && errors.emailError !== ''}
                    data-testid = "email"
                    type="email" 
                    placeholder="Email address" 
                  />

                  <Form.Control.Feedback type = "invalid">{errors.emailError}</Form.Control.Feedback>
                  <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

                </Form.Group>

                <Form.Group className = "mt-3">

                  <Form.Control 
                    onChange = {(e) => {handleChange("password", e.target.value)}}
                    isInvalid = {!!errors.passwordError}
                    isValid = {!errors.passwordError && errors.passwordError !== ''}
                    type="password" 
                    data-testid = "password"
                    placeholder="Password" 
                  />

                  <Form.Control.Feedback type = "invalid">{errors.passwordError}</Form.Control.Feedback>
                  <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>
                  
                </Form.Group>

              </div>


              <div className="d-flex flex-column mt-5">
                
                <div className = "d-flex">
                  <h4> Personal Details</h4>
                </div>

              <Form.Group className = "mt-3">
                <Form.Control 
                  onChange = {(e) => {handleChange("firstName", e.target.value)}}
                  isInvalid = {!!errors.firstNameError}
                  isValid = {!errors.firstNameError && errors.firstNameError !== ''}
                  type="input" 
                  data-testid = "firstName"
                  placeholder="First Name" 
                />

                <Form.Control.Feedback type = "invalid">{errors.firstNameError}</Form.Control.Feedback>
                  <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>

              <Form.Group className = "mt-3">

                <Form.Control 
                  onChange = {(e) => {handleChange("lastName", e.target.value)}}
                  isInvalid = {!!errors.lastNameError}
                  isValid = {!errors.lastNameError && errors.lastNameError !== ''}
                  type="input" 
                  data-testid = "lastName"
                  placeholder="Last Name" 
                />

                <Form.Control.Feedback type = "invalid">{errors.lastNameError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>

              <Form.Group className = "mt-3">

                <Form.Control 
                  onChange = {(e) => {handleChange("street", e.target.value)}}
                  isInvalid = {!!errors.streetError}
                  isValid = {!errors.streetError && errors.streetError !== ''}
                  type="input" 
                  data-testid = "streetName"
                  placeholder="Your Street Name" 
                />

                <Form.Control.Feedback type = "invalid">{errors.streetError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>

              <Form.Group className = "mt-3">

                <Form.Control 
                  onChange = {(e) => {handleChange("city", e.target.value)}}
                  isInvalid = {!!errors.cityError}
                  isValid = {!errors.cityError && errors.cityError !== ''}
                  type="input" 
                  data-testid = "cityName"
                  placeholder="Your City Name" 
                />

                <Form.Control.Feedback type = "invalid">{errors.cityError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>


              </Form.Group>

              <Form.Group className = "mt-3">

                <Form.Select placeholder="Select Your State">
                  <option value="1">VIC</option>
                  <option value="2">NSW</option>
                  <option value="3">ACT</option>

                </Form.Select>
              
              </Form.Group>

              <Form.Group className = "mt-3">

                <Form.Control 
                    onChange = {(e) => {handleChange("postalCode", e.target.value)}}
                    isInvalid = {!!errors.postalCodeError}
                    isValid = {!errors.postalCodeError && errors.postalCodeError !== ''}
                    type="input" 
                    data-testid = "postCode"
                    placeholder="Your Postal Code" 
                />

                <Form.Control.Feedback type = "invalid">{errors.postalCodeError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>

              </Form.Group>


              <Form.Group className = "mt-3">
        
                <Form.Control 
                  onChange = {(e) => {handleChange("suburb", e.target.value)}}
                  isInvalid = {!!errors.suburbError}
                  isValid = {!errors.lastNameError && errors.lastNameError !== ''}
                  type="input" 
                  data-testid = "suburbCode"
                  placeholder="Your Suburb" 
                />

                <Form.Control.Feedback type = "invalid">{errors.suburbError}</Form.Control.Feedback>
                <Form.Control.Feedback type = "valid">Looks good</Form.Control.Feedback>


              </Form.Group>

              </div>

              <div className = "d-flex justify-content-center flex-gap-20 mt-5">
                <Button type = "submit" variant = "success">Submit</Button>
                <Button type = "submit" variant = "success">Cancel</Button>

              </div>
        

            </Form>
        
        </Card.Body>

      </Card>

    </div>

  )



}


export default Signup;
