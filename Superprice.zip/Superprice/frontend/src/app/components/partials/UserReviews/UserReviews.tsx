// Contains the component for user reviews

import {useContext, useEffect, useState} from "react"
import { ProductContext } from "../../Contexts/ProductContext";

import { Button, Card, Form } from "react-bootstrap";
import { Modal } from "react-bootstrap";
import { getProductReviews, saveReview } from "../../axios/AxiosCommands";
import { ProductReview } from "../../../types/AxiosTypes";
import { userContext } from "../../Contexts/UserContext";


function UserReviews(){

    const {state} = useContext(ProductContext);
    const {user} = useContext(userContext)

    const [otherReviews, setOtherReviews] = useState<ProductReview[] | null>(null);
    const [review, setReview] = useState('');
    const [rating, setRating] = useState<string>('');
    const [show, setShow] = useState(false);
    const [count, setCount] = useState<number>(0);


    function handleClose(){

        setCount(0);
        setReview('')
        setShow(false)
        setRating('')

    }

    const handleShow = () => setShow(true);

    useEffect(() => {

        async function fetchProductReviews(){

            console.log(state.individualSelectedProduct?.id, "product id")

            const response = await getProductReviews(state.individualSelectedProduct?.id as number)
            setOtherReviews(response.data);

            console.log(response.data, "useeffect")

        }

        fetchProductReviews();

    }, [show, state.individualSelectedProduct?.id])

    function handleReview(event: React.ChangeEvent<HTMLInputElement>){

        setReview(event.target.value)

        setCount(event.target.value.length);
    }

    function handleRating(event: React.ChangeEvent<HTMLSelectElement>){
        const selectedRating = (event.target.value);

        setRating(selectedRating);

    }

    async function handleReviewSubmit(){

        const reviewObject = {
            user: user, 
            product: state.individualSelectedProduct, 
            content: review, 
            rating: parseInt(rating)
        }

        try {
            const data = await saveReview(reviewObject);

            // We will now update the list of reviews to accomdate the user's review

            setOtherReviews([...otherReviews as ProductReview[], data])
            setReview('')
            setCount(0)
            setRating('')
        } 
        
        catch (error) {
            if (error) {
                // This means it's an Axios error with a response from the server
                alert(`Something has gone wrong with your review. Please try again.`);
            } 
        
        }

    
    }


    return(

        <div>

            <Button onClick={handleShow}>Add/View Reviews</Button>

            <Modal show = {show} onHide = {handleClose} centered className="p-2">
                <Modal.Header closeButton>
                    <Modal.Title>View Reviews - {state.individualSelectedProduct?.name} - {state.individualSelectedProduct?.supermarket.name}</Modal.Title>
                </Modal.Header>

                <Modal.Body>

                    <div>

                        <h5>Other's Reviews</h5>
                            
                        {otherReviews?.map((item) => (

                            <Card className = "mt-3 p-2">
                                <p>Review By: {item.user.firstName} {item.user.lastName} {user?.userId === item.userId ? "(You)" : null}</p>
                                <p>Date Created: {item.reviewDate}</p>
                                <p>Rating: {item.rating} / 5</p>
                                <p key={item.id}>{item.content}</p>

                            </Card>

                        ))}

                    </div>

                    <div>    

                        {user ? 

                            <div>

                                <h5 className="mt-3">Add your own review here</h5>

                                <Form.Group className="p-2">
                                    <Form.Control value={review} placeholder="Add your review here" onChange={handleReview} as = "textarea"></Form.Control>
                                    <p>{count}/100</p>
                                    <Form.Select aria-label="Select Rating" onChange={handleRating}>
                                        <option value = {"null"}>Select Your Rating </option>
                                        <option value={"0"}>0</option>
                                        <option value={"1"}>1</option>
                                        <option value={"2"}>2</option>
                                        <option value={"3"}>3</option>
                                        <option value={"4"}>4</option>
                                        <option value={"5"}>5</option>
                                    </Form.Select>
                                    
                                </Form.Group>

                                <Button onClick={handleReviewSubmit} disabled = {count > 100 || count === 0 || rating.length === 0 || rating === "null"}>Submit Review</Button>
                                
                            </div>
                        
                        :
                            <h5 className="mt-3 text-center">Please Sign in to add review</h5>


                        }


                    
                        </div>

                
                </Modal.Body>


            </Modal>

        </div>


    )

    

}

export default UserReviews;