// Contains similar products, and price comparison feature

import React, {useContext, useEffect } from 'react';
import {useNavigate } from 'react-router-dom';
import { Card, Container, Row, Col } from 'react-bootstrap';
import { ProductContext } from '../../Contexts/ProductContext';
import { getSubCategories } from '../../axios/AxiosCommands';
import { thumbnail } from '@cloudinary/url-gen/actions/resize';
import { AdvancedImage } from '@cloudinary/react';
import { cld } from '../../../utils/Cloudinary';
import { productType } from '../../../types/AxiosTypes';

function ProductComparison() {

    const {state, dispatch} = useContext(ProductContext);
    const navigate = useNavigate();


    useEffect(() => {
        // Retrieve similar products, based on subCategory prop

        async function getSubProducts() {

            const productSubCat = state.individualSelectedProduct?.subCategory
            let productList = await getSubCategories(productSubCat as string)

            productList = productList.filter(item => item.id !== state.individualSelectedProduct?.id)
                .sort((a, b) => a.id - b.id);

            dispatch({type: 'setSimilarProductList', payload: productList})
        }

        getSubProducts();

    }, [dispatch, state.individualSelectedProduct])


    function handleRedirect(event: React.MouseEvent<HTMLDivElement>){

        const id = event.currentTarget.id

        // So you get the individual item
        const item = state.productsList?.find((item) => String(item.id) === id);

        dispatch({type: 'setIndividualProduct', payload: item as productType})

        navigate(`/product/${item?.name}/${item?.id}`)

    }


    return(

        <div className = "">

            {state.similarProductList !== null ? (
                <Container fluid className="p-4">
                    <Row className="d-flex flex-nowrap overflow-auto">
                        {state.similarProductList.map((similarProduct) => (
                            <Col className="flex-shrink-0 mb-4 pr-2" style={{ minWidth: '300px' }}>
                                <Card onClick={handleRedirect} className="p-7" id={String(similarProduct.id)}>
                                <AdvancedImage cldImg={cld.image(similarProduct.productImage).resize(thumbnail().width(150).height(150))} />
                                    <Card.Body>
                                        <Card.Title>{similarProduct.name}</Card.Title>
                                        <Card.Text>${similarProduct.price}</Card.Text>
                                        <Card.Text>{similarProduct.supermarket.name}</Card.Text>
                                    </Card.Body>
                                </Card>
                            </Col>
                        ))}
                    </Row>
                </Container>
            ) :
                <div>
                    {/* Placeholder content if needed */}
                </div>
            }
                    </div>
                )
            }

export default ProductComparison;