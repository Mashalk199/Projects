/* Contains the individual product item
 This component will then be used either through category, search or general clicking when user clicks on an item
they will be navigated to this component.*/ 

import React, {useContext, useEffect} from 'react';
import { useParams } from 'react-router-dom';

import { ProductContext } from '../../Contexts/ProductContext';
import { cld } from '../../../utils/Cloudinary';
import '../../../styles/globalstyles.css'
import './ProductItem.css'

import { AdvancedImage } from '@cloudinary/react';
import { Button } from 'react-bootstrap';
import { thumbnail } from '@cloudinary/url-gen/actions/resize';
import { getProduct } from '../../axios/AxiosCommands';
import { CartContext } from '../../Contexts/ShoppingCartContext';
import ProductComparison from './ProductComparison';
import UserReviews from '../UserReviews/UserReviews';


function ProductIndividual(){

    const {state, dispatch} = useContext(ProductContext);    
    const {cartDispatch} = useContext(CartContext);

    const {id} = useParams();

    useEffect(() => {

        // Here we will get the product again if the user refreshes

        async function getItemFromBackEnd(){
        
            if(state.individualSelectedProduct === null){
                
                // The individual product is empty so fetch from backend
                const item = await getProduct(id as string)
                dispatch({type: 'setIndividualProduct', payload: item})
            
            }
        }


        getItemFromBackEnd();

    }, [dispatch, id, state.individualSelectedProduct])


    function handleAddToCart(event: React.MouseEvent<HTMLButtonElement>){

        // Here we are asserting that the individual product is not null with "!"
        cartDispatch({type:'addToCart', payload: state.individualSelectedProduct!})

    }

    return(

        <div className = "page-product-container mt-5 p-5">

        <div className="d-flex flex-column  flex-gap-30">

            <div className = "d-flex flex-column flex-gap-30">

                <div className = "d-flex justify-content-center align-items-center flex-gap-100 ">
                 
                    <div className = "d-flex flex-gap-30 product-image">
                        <AdvancedImage cldImg={cld.image(state.individualSelectedProduct?.productImage).resize(thumbnail().width(350).height(350))}/>

                    </div>

                    <div className = "d-flex p-4 flex-column product-name">

                       <div className='d-flex'>    
                            <h3>{state.individualSelectedProduct?.name}</h3>
                       </div>

                       <div className='d-flex'>
                           <h3>${state.individualSelectedProduct?.price}</h3>
                       </div>

                       <div className='d-flex justify-content-end'>
                            <Button onClick={handleAddToCart} variant = "success">Add to cart</Button>
                        </div>

                    </div>

                </div>

            </div>

            <div className='d-flex flex-column bg-body-tertiary'>
            
                <div className=''>

                    <h3>Product Details</h3>

                    <p>{state.individualSelectedProduct?.productDescription}</p>

                </div>


                <div className=''>

                    <h3>User Reviews</h3>

                    <UserReviews />

                </div>

            </div>

            <div className=''>

                    <h3>Other Supermarkets with Low Prices</h3>

                    <ProductComparison/>

                </div>

        
        </div>

        </div>
    )


}

export default ProductIndividual;