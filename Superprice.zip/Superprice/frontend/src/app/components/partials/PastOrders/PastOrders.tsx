import React, { useState, useContext, useEffect } from "react";
import { getAllUserOrders } from "../../axios/AxiosCommands";
import { userContext } from "../../Contexts/UserContext";
import { Order } from "./GroupOrders";
import { transformOrderResponse } from "./GroupOrders";
import { cld } from "../../../utils/Cloudinary";

import { Button, Card } from "react-bootstrap";

import { Modal } from "react-bootstrap";

import { AdvancedImage } from "@cloudinary/react";
import { thumbnail } from "@cloudinary/url-gen/actions/resize";

function PastOrders() {
    const { user } = useContext(userContext);

    const [showModal, setShowModal] = useState<boolean>(false);

    const [modalData, setModalData] = useState<Order | null> (null);
    const [orders, setOrders] = useState<Order[] | null>(null);

    useEffect(() => {
        async function getUsersPastOrders() {
            // In this we will fetch all the orders of the user
            console.log(user?.userId, "user ID mate")

            const data = await getAllUserOrders(user?.userId as number)

            const updatedOrders = transformOrderResponse(data)
            
            console.log(updatedOrders, "updated orders")

            setOrders(updatedOrders);
        }

        getUsersPastOrders();
    }, [user?.userId])

    function handleModalDisplay(event:React.MouseEvent<HTMLButtonElement>){

        // Take the item from index,, store in modal state and display that

        const orderIndex = parseInt(event.currentTarget.id)

        setModalData(orders![orderIndex])

        setShowModal(true)

    }

    return (
        <div>
            {orders?.length === 0 ?
                <h1 className="mt-5 text-center">You have not ordered anything, yet!</h1>
                :
                <div className="d-flex flex-column justify-content-center align-items-center mt-5">

                    <h4>Your Orders</h4>

                        <div>

                            <Card className="text-left" style={{width: '880px'}}>

                                {orders?.map((order, index) => 

                                    <div>
                                        <Card.Title>
                                            <p>SuperPrice Delivery</p>
                                            <p>Order Number: </p>
                                            <p>#{order.orderId}</p> 
                                        </Card.Title>

                                        <Button id={String(index)} onClick={handleModalDisplay} variant="success">View Order Details</Button>

                                        <hr></hr>


                                    </div>
                                    

                                )}
                            
                            </Card>


                        </div>
                </div>
            }


            <Modal show={showModal} onHide={() => {setShowModal(false)}} size="lg">

                <Modal.Header closeButton>
                    <Modal.Title>Your Groceries</Modal.Title>
                </Modal.Header>

                <Modal.Body>

                    {modalData?.products.map((item, counter: number) =>  

                        <div className="d-flex align-items-center flex-gap-10 mt-3">

                            <div>
                                <AdvancedImage cldImg={cld.image(item.productImage).resize(thumbnail().width(150).height(150))}></AdvancedImage>
                            </div>

                            <div>
                                <h5>{item.name}</h5>           
                                <h6>Quantity: {item.quantity}</h6>   
                                <h6>Total: ${(item.quantity! * item.price).toFixed(2)}</h6>          
                            </div>

                        </div>

                    )}

                </Modal.Body>

            </Modal>



        </div>
    )
}

export default PastOrders;
