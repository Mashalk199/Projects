// This file is used to group orders 


type Supermarket = {
    name: string;
    location: string;
    postCode: string;
    id: number;
}

type Product = {
    id: number;
    name: string;
    price: number;
    productCategory: string;
    supermarket: Supermarket;
    productImage: string
    quantity?: number;
}

type User = {
    userId: number;
    firstName: string;
    lastName: string;
    email: string;
}

export type Order = {
    orderId: number;
    totalCost: number;
    products: Product[];
    user: User;
}

export function transformOrderResponse(response: any[]): Order[] {
    const orders: Order[] = [];

    response.forEach((orderResponse, index) => {
        const order: Order = {
            orderId: index + 1,  // Assuming orders are in sequence
            totalCost: orderResponse.totalCost,
            products: [],
            user: {
                userId: orderResponse.user.userId,
                firstName: orderResponse.user.firstName,
                lastName: orderResponse.user.lastName,
                email: orderResponse.user.email
            }
        };

        const productMap = new Map<number, Product>();

        orderResponse.orderProducts.forEach((orderProduct: any) => {
            const product: Product = {
                id: orderProduct.product.id,
                name: orderProduct.product.name,
                price: orderProduct.product.price,
                productCategory: orderProduct.product.productCategory,
                supermarket: orderProduct.product.supermarket,
                productImage: orderProduct.product.productImage
            };

            if (productMap.has(product.id)) {
                productMap.get(product.id)!.quantity! += 1;
            } else {
                product.quantity = 1;
                productMap.set(product.id, product);
            }
        });

        order.products = Array.from(productMap.values());
        orders.push(order);
    });

    return orders;
}
