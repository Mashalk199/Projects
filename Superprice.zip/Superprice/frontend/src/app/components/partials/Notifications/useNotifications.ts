// Contains the notification functionality 

import { useEffect, useCallback } from 'react';
import { toast } from 'react-toastify';
import { productType } from '../../../types/AxiosTypes';

function useProductNotification(products: productType[]) {

  const notifyRandomProduct = useCallback(() => {
    if (!products || products.length === 0) return;

    console.log("Custom hook in here...")

    // Pick a random product
    const randomProduct = products[Math.floor(Math.random() * products.length)];

    randomProduct.price = parseFloat((randomProduct.price * 0.9).toFixed(2));  // Example: 10% discount

    toast(`Price for ${randomProduct.name} is now $${(randomProduct.price).toFixed(2)}!`);
  }, [products]);

  useEffect(() => {
    const interval = setInterval(() => {
      notifyRandomProduct();
    }, 30 * 1000); 

    // Cleanup interval when component unmounts
    return () => clearInterval(interval);
  }, [notifyRandomProduct]);

}

export default useProductNotification;
