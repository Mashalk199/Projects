import { Navigate } from "react-router-dom";
import { useEffect, useState } from "react";

function PrivateRoutes({ children} : any) {
  const [loggedIn, setLoggedIn] = useState<boolean | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');

    // It can also be the token exists but their jwt session has expired..



    if(token !== null){
        // So a token exists then the user is logged in and can visit other routes.
      setLoggedIn(true)
    }

    else{
       // User is not logged in so they cannot visit the respective route.
      alert('Your currently not logged in')
      setLoggedIn(false)
    }
    
  }, []);

  if (loggedIn === false) {
    return <Navigate to="/Signin" />;
  } else {
    return children;
  }
}

export default PrivateRoutes;
