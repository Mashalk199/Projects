// This contains a shopping cart component 

import React, {useContext} from "react"
import { useNavigate } from "react-router";

import { CartContext } from "../../Contexts/ShoppingCartContext";
import { groupCarts } from "../../../utils/GroupCart";
import { cld } from "../../../utils/Cloudinary";
import { productType } from "../../../types/AxiosTypes";
import './Cart.css'
import '../../../styles/globalstyles.css'


import {Button, Offcanvas} from 'react-bootstrap';
import { AdvancedImage } from "@cloudinary/react";
import { thumbnail } from "@cloudinary/transformation-builder-sdk/actions/resize";
import { userContext } from "../../Contexts/UserContext";

type GroupCarts = {
  item: productType, 
  quantity: number
}

function ShoppingCart(){

    const {cartState, cartDispatch} = useContext(CartContext);
    const {user} = useContext(userContext);

    const navigate = useNavigate();
    let groupedCarts : GroupCarts[] = groupCarts(cartState.cart);

    function handleAddItem(event: React.MouseEvent<HTMLButtonElement>){
      // So the item already exists we just need to add one more to it 
      const productIndex = parseInt(event.currentTarget.getAttribute('data-id') as string);
      cartDispatch({type: 'addToCart', payload: groupedCarts[productIndex].item})
    }

    function handleRemoveItem(event: React.MouseEvent<HTMLButtonElement>){
      // So the item already exists we just need to remove one more from it 
      const productIndex = parseInt(event.currentTarget.getAttribute('data-id') as string);
      cartDispatch({type: 'removeFromCart', payload: groupedCarts[productIndex].item})
    }

    function handleRemoveAllItems(event: React.MouseEvent<HTMLButtonElement>){
      cartDispatch({type: 'removeAllItems', payload: null})
    }

    function handleClose(){
      cartDispatch({type: 'toggleVisibility', payload: false})
    }

    function handleCheckoutNavigate(){

      // So this means the user exists, then we will navigate to the checkout
      if(user !== null ){

        cartDispatch({type: "toggleVisibility", payload: false})

        navigate('/Checkout')

      }

      else{

        cartDispatch({type: "toggleVisibility", payload: false})

        // User does not exist lets redirect them to the sign up page..
        navigate('/Signup')

      }


    }

    return (
        <div>

          <Offcanvas show = {cartState.cartVisible} onHide = {handleClose} placement="end">
            <Offcanvas.Header closeButton>
              <Offcanvas.Title>Your Cart ({cartState.cart.length}) Items</Offcanvas.Title>
            </Offcanvas.Header>

            <Offcanvas.Body>
              {cartState.cart?.length === 0 ? (
                <p>Your cart is empty.</p>
              ) : (
                groupedCarts.map(({item, quantity}, index) => (
                  <div className="d-flex flex-column mb-5 cart-item-box" key={item.id}>
                    <div className="d-flex justify-content-end flex-gap-10">
                      <Button data-id = {index} variant = "light" onClick={handleAddItem}>+</Button>
                      <Button data-id = {index} variant = "light"onClick = {handleRemoveItem}>-</Button>
                    </div>
                    <div className="d-flex flex-gap-20 align-items-center">
                      <AdvancedImage cldImg={cld.image(item.productImage).resize(thumbnail().width(100).height(100))}></AdvancedImage>
                      <div className="mr-5">
                        <div>{item.name}</div>
                        <div className = "mt-20">
                          Quantity: {quantity}
                        </div>
                      </div>
                    </div>

                    <div className="d-flex justify-content-end">
                      <h3>${(item.price * quantity).toFixed(2)}</h3>
                    </div>

                    <Button variant="danger" className="mt-4" onClick={handleRemoveAllItems}>Remove All</Button>
                  </div>
                ))
              )}

              <div className = "d-flex align-items-center flex-gap-20 justify-content-between">
                  
                <h5>Current Total: ${cartState.currentTotal.toFixed(2)}</h5>

                <Button variant = "success" 
                      onClick={handleCheckoutNavigate}
                      disabled = {cartState.cart.length === 0}
                      >Checkout</Button>
              </div>

            </Offcanvas.Body>

          </Offcanvas>
            
        </div>
    );
};



export default ShoppingCart;
