// Imports
import React, { useEffect, useContext } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Button, Card } from "react-bootstrap";
import { AdvancedImage } from "@cloudinary/react";
import { thumbnail } from "@cloudinary/url-gen/actions/resize";
import { getAllProducts, getSimilarProducts } from "../../axios/AxiosCommands";
import { ProductContext } from "../../Contexts/ProductContext";
import './Product.css';
import { cld } from "../../../utils/Cloudinary";

function Product() {
  // Hooks and Context
  const { state, dispatch } = useContext(ProductContext);
  const navigate = useNavigate();
  const { id } = useParams()

  // Fetch products on component mount
  useEffect(() => {
    async function getProducts() {
      const productsList = await getAllProducts();
      dispatch({ type: 'setProducts', payload: productsList });
    }

    async function getProductsByCategory(category: string) {
        const productList = await getSimilarProducts(category)
        dispatch({ type: 'setProducts', payload: productList })
    }

    if (id) {

        // get products by that category
        getProductsByCategory(id)
    }
    else {
        
        // Render all/featured products
        getProducts();
    }
  }, [dispatch, id]);

  // Event Handlers
  function handleUpdatedProductNavigate(event: React.MouseEvent<HTMLButtonElement>) {
    const productIndex = parseInt(event.currentTarget.getAttribute('data-id') as string);
    const currentItem = state.updatedProductsList![productIndex];
    dispatch({ type: 'setIndividualProduct', payload: currentItem });
    navigate(`/product/${currentItem.name}/${currentItem.id}`);

  }

  function handleProductNavigate(event: React.MouseEvent<HTMLButtonElement>) {
    const productIndex = parseInt(event.currentTarget.getAttribute('data-id') as string);
    const currentItem = state.productsList![productIndex];
    dispatch({ type: 'setIndividualProduct', payload: currentItem });
    navigate(`/product/${currentItem.name}/${currentItem.id}`);
  }

  // Render Component
  return (
    <div>
      <div className="products-container">
        {state.updatedProductsList && state.updatedProductsList.length > 0 ? (
          state.updatedProductsList.map((product, index) => (
            <div className="product-card" key={index}>
              <Card 
                key={index} 
                data-id={index} 
                className="product-card-individual" 
                onClick={handleUpdatedProductNavigate} 
                style={{ width: '18rem' }}
              >
                <AdvancedImage cldImg={cld.image(product.productImage).resize(thumbnail().width(150).height(150))} />
                <Card.Body>
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text>{product.productDescription}</Card.Text>
                  <Button variant="success" data-id={index} onClick={handleUpdatedProductNavigate}>Shop Now</Button>
                </Card.Body>
              </Card>
            </div>
          ))
        ) : (
          state.searchContent.length > 0 && <p>Nothing to show for this search item.</p>
        )}

        {state.productsList && state.updatedProductsList === null ? (
          state.productsList.map((product, index) => (
            <div className="product-card" key={index}>
              <Card 
                key={index} 
                data-id={index} 
                className="product-card-individual" 
                onClick={handleProductNavigate} 
                style={{ width: '18rem' }}
              >
                <AdvancedImage cldImg={cld.image(product.productImage).resize(thumbnail().width(150).height(150))} />
                <Card.Body>
                  <Card.Title>{product.name}</Card.Title>
                  <Card.Text>{product.productDescription}</Card.Text>
                  <Button variant="success" data-id={index} onClick={handleProductNavigate}>Shop Now</Button>
                </Card.Body>
              </Card>
            </div>
          ))
        ) : (
          state.productsList === null && state.updatedProductsList === null && <p>Loading Items ..</p>
        )}
      </div>
    </div>
  );
}

export default Product;
