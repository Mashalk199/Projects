// Create a component for a search bar

import React, {useContext} from "react";

import {Form} from "react-bootstrap"
import { ProductContext } from "../../Contexts/ProductContext";
import Product from "./Product";

function SearchBar(){

    const {dispatch} = useContext(ProductContext);

    function handleChange(event: React.ChangeEvent<HTMLInputElement>){

        if(event.target.value.length === 0){
            
            // If the length is 0 means we reset and show everything again
            dispatch({type: "resetProducts", payload: null})

        }

        // If length is not zero then present it
        dispatch({type: 'searchUpdate', payload: event.target.value});
    }

    return(

        <div>

            <div className="p-2 mt-3">

                <Form.Control type = "input" placeholder = "Search Here" onChange={handleChange}></Form.Control>
                
            </div>

            <Product />

        
        </div>


    )

}

export default SearchBar;