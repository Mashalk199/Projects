import React, {ReactNode, createContext, useReducer} from "react";
import { productsReducer } from "../Reducers/productsReducer";
import { productType } from "../../types/AxiosTypes";

// Initial state for the product context.
const initalState: CurrentState = {    
    searchContent: "",
    selectedCategory: "",
    productsList: null,
    updatedProductsList: null,
    individualSelectedProduct: null,
    similarProductList: null,
    productReviews: null
}

export interface CurrentState{
    searchContent: string 
    selectedCategory: string
    productsList: productType[] | null
    updatedProductsList: productType[] | null 
    individualSelectedProduct: productType | null
    similarProductList: productType[] | null
    productReviews: any | null
}

export type CurrentAction = {
    type: 'setProducts' | 'searchUpdate' | 'resetProducts' | 'setIndividualProduct' | 'setSimilarProductList'
    payload: productType[] | string | null | productType | productType[]
}

// Specifies that the children has to be of type 'ReactNode'
//  or in other words, a react component (for which the 
//  context provider can operate within).
type ProductContextProviderProps = {
    children: ReactNode
}

// Create a context for the product state and dispatch.
export const ProductContext = createContext<{state: CurrentState, dispatch: React.Dispatch<CurrentAction>}> ({
    state: initalState, 
    dispatch: () => {},
})

// Product context provider component.
export const ProductsContextProvider = ({children} : ProductContextProviderProps) => {
    const [state, dispatch] = useReducer(productsReducer, initalState);
    // Uses the productsReducer above to manage state transitions.
    return(
        // Provide the Product context and state to its children.
        <ProductContext.Provider value={{state, dispatch}}>
                {children}
        </ProductContext.Provider>

    )
}