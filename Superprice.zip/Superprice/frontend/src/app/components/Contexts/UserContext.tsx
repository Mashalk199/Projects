import React, { createContext, useState, useEffect } from "react";
import { User } from "../../types/AxiosTypes";
import { verifyUser } from "../axios/AxiosCommands";
import { AxiosError } from "axios";
// Defines the type for the user context.
type userContextType = {
  user: User | null,
  setUser: React.Dispatch<React.SetStateAction<User | null>>

};
// Defines the props for the UserContextProvider component.
type userContextProviderProps = {
  children: React.ReactNode;
};
// Creates a context for the user state and setUser function.
export const userContext = createContext({} as userContextType);
// User context provider component.
export const UserContextProvider = ({ children }: userContextProviderProps) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
  // Function to verify the user's token.
    async function verifyUserToken(){
      
      const token = localStorage.getItem('token');

      if(token){
        try {
          const response = await verifyUser(token);

          // Assuming the request was successful, set the user.
          setUser(response.data);
        } catch (error) {
          const axiosError = error as AxiosError;
          // Check if the error response has a status of 401 or 404.
          if (axiosError.response && (axiosError.response.status === 401 || 
                                      axiosError.response.status === 404)) {
            localStorage.removeItem('token'); // Remove token on unauthorized or not found.
          } else {
            console.error('Error verifying user:', error);
          }
        }
      }
    }

    verifyUserToken();

  }, []);


  
  // Provides the User context and user state to its children.
  return (
    <userContext.Provider value={{ user, setUser }}>
      {children}
    </userContext.Provider>
  );
};