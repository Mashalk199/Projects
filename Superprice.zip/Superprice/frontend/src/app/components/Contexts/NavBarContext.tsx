import React, { ReactNode, createContext, useReducer } from "react";

// Initial State
const initialState: NavbarState = {
    isSignupVisible: false,
    isSigninVisible: false
};

export interface NavbarState {
    isSignupVisible: boolean,
    isSigninVisible: boolean
}

export type NavbarAction = {
    type: 'SHOW_SIGNUP' | 'HIDE_SIGNUP';
}

type NavbarContextProviderProps = {
    children: ReactNode;
}
// Create a context for Navbar state and dispatch
export const NavbarContext = createContext<{ navBarState: NavbarState, navBarDispatch: React.Dispatch<NavbarAction> }> ({
    navBarState: initialState,
    navBarDispatch: () => {},
});
// Reducer function for Navbar state
function navbarReducer(state: NavbarState, action: NavbarAction): NavbarState {
    switch (action.type) {
        case "SHOW_SIGNUP":
            return { ...state, isSignupVisible: true };
        case "HIDE_SIGNUP":
            return { ...state, isSignupVisible: false };
        default:
            return state;
    }
}
// Navbar context provider component
export const NavbarContextProvider: React.FC<NavbarContextProviderProps> = ({ children }) => {
    const [navBarState, navBarDispatch] = useReducer(navbarReducer, initialState);

    return (
        // Provide the Navbar context and state to its children
        <NavbarContext.Provider value={{ navBarState, navBarDispatch }}>
            {children}
        </NavbarContext.Provider>
    );
}
