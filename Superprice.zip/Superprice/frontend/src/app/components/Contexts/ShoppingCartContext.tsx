import React, {ReactNode, createContext, useEffect, useReducer} from "react";
import { cartReducer } from "../Reducers/cartReducer";
import { productType } from "../../types/AxiosTypes";

// The initial state for the cart context.
const initalState: CurrentState = {
    cart: [],
    currentTotal: 0,
    cartVisible: false
}

export interface CurrentState{
    cart: productType[],
    currentTotal: number
    cartVisible: boolean

}

export type CurrentAction = {
    type: 'addToCart' | 'removeFromCart' | 'toggleVisibility' | 'removeAllItems'
    payload: productType | boolean | null
}

type CartContextProviderProps = {
    children: ReactNode
}

// Creates a context for the cart state and dispatch.
export const CartContext = createContext<{cartState: CurrentState, cartDispatch: React.Dispatch<CurrentAction>}>({
    cartState: initalState, 
    cartDispatch: () => {},
})

// Cart context provider component.
export const CartsContextProvider = ({children} : CartContextProviderProps) => {
    // Uses the cartReducer to manage state transitions and persist the state in local storage.
    const [cartState, cartDispatch] = useReducer(cartReducer, initalState, () => {
        const localData = localStorage.getItem('cart');
        return localData ? JSON.parse(localData) : initalState;
      });
      // Stores the cart state in local storage whenever it changes.
      useEffect(() => {
        localStorage.setItem('cart', JSON.stringify(cartState));
      }, [cartState]);
      // Provides the Cart context and state to its children.
      return (
        <CartContext.Provider value={{ cartState, cartDispatch }}>
          {children}
        </CartContext.Provider>
      );


}