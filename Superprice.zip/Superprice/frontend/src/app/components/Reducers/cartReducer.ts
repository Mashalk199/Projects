import { productType } from "../../types/AxiosTypes"
import { CurrentAction, CurrentState} from "../Contexts/ShoppingCartContext"

export function cartReducer(state: CurrentState, action: CurrentAction) : CurrentState{
    
    switch(action.type){

        case 'addToCart':
            // Adds an item to the end of the cart
            let itemToAdd = action.payload as productType
            return {...state, currentTotal: state.currentTotal + itemToAdd.price,  cart: [...state.cart, itemToAdd ]}

        case 'removeFromCart':
            // Removes specified item from the state.
            let itemToRemove = action.payload as productType
            
            const index = state.cart.findIndex((item) => item.id === itemToRemove.id)
            if (index !== -1) {
              // Create a new array to avoid mutating state
              const newCart = [...state.cart];
              
              // Remove the item from the array
              newCart.splice(index, 1);
      
              // Update the total price
              const newTotal = state.currentTotal - state.cart[index].price;
              
              return { ...state, currentTotal: newTotal, cart: newCart };
            }
            
            return state;

        case 'toggleVisibility':
            // Toggles the visibility of the cart
            let showCart = action.payload as boolean
            return {...state, cartVisible: showCart}

        case 'removeAllItems':
            return {...state, currentTotal: 0, cart: []}

        default:
            return state 

    }
}