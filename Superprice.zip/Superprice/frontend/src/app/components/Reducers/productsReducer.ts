import { productType } from "../../types/AxiosTypes"
import { CurrentAction, CurrentState} from "../Contexts/ProductContext"

export function productsReducer(state: CurrentState, action: CurrentAction) : CurrentState {
    
    switch (action.type) {

        case 'setProducts':
            
            return {...state, 
                productsList: action.payload as productType[]
            }

        case 'searchUpdate':
            
            let stringToUpdate = action.payload as string 

            // The ! here tells typescript to ignore the nulls

            /* Here we are casting the search input as lower case and for the products as 
               well to ensure if we get accurate results */

            return {...state, 
                searchContent: stringToUpdate, 
                updatedProductsList: [...state.productsList!.filter(product => 
                    product.name.toLowerCase().includes(stringToUpdate.toLowerCase()))]
                }

        case 'resetProducts':

            return {...state, updatedProductsList: null}

        case 'setIndividualProduct':

            let individualProduct = action.payload as productType

            return {...state, individualSelectedProduct: individualProduct }
            
        case 'setSimilarProductList':
            
            return {...state,
                similarProductList: action.payload as productType[]
            }

        default:
            return state

    }
}