export type productType = {
    id: number,
    name: string, 
    price: number, 
    productCategory:string, 
    subCategory: string,
    productGroup: string,
    productDescription: string, 
    productImage: string,
    supermarket: supermarketType
}

export type supermarketType = {
    supermarketId: number,
    name: string,
    location: string,
    postCode: string
}

export type LoginUserType = {
    email: string, 
    password: string
}


export type User = {
    userId: number
    email: string,
    password: string,
    firstName: string,
    lastName: string,
    street: string,
    city: string,
    state: string,
    postalCode: string,
    suburb: string,
}

export type AuthUser = {
    user: User, 
    jwtToken: string
}


export type UserForm = {
    email: string,
    password: string,
    firstName: string,
    lastName: string,
    street: string,
    city: string,
    state: string,
    postalCode: string,
    suburb: string,
}

type TimeSlot = {
    date: string;
    availableTimeSlots: string[];
}

export type TimeSlotsDataType = TimeSlot[];

export type ProductReview = {
    id:number,
    reviewDate: string,
    rating: number,
    user: User
    content: string, 
    userId: number,
    productId: number
}

export type productReviewSubmit = {
    user: User | null, 
    product: productType | null, 
    content: string, 
    rating: number
}

type orderProducts = {
    product: productType, 
    productId: number
}

export type Orders = {
    orderProducts: orderProducts[]
    totalCost: number, 
    user: User
    
}
