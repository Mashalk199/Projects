import { productType } from "../types/AxiosTypes"

export function groupCarts(carts: productType[]){

    const groupedItems: any = []

    carts.forEach((item) => {

        if(groupedItems[item.id]){
            // This means that the item already exists
            groupedItems[item.id].quantity +=1
        } else{
            // This means that the item with this id does not exist
            groupedItems[item.id] = {item, quantity: 1}
        }

    })

    return groupedItems;


}