import {Cloudinary} from "@cloudinary/url-gen";


export const cld = new Cloudinary({
    cloud: {
      cloudName: 'dynquq4lx'
    }
  });


// Export Cloudinary object -- contains Cloudinary Cloud Name