src/app	-	Application entry point
src/locale	-	Internationalization files
src/styles	@styles/*	Global styles
src/app/components/elements	@components/elements/*	Generic and simple components like buttons, inputs, etc.
src/app/components/partials	@components/partials/*	More Complex ui related components
src/app/components/views	@components/views/*	View or Screens
src/app/components/layouts	@components/layouts/*	Components used to organize the application's layout
src/app/types	@app/types/*	Global types
src/app/hooks	@hooks/*	Custom hooks
src/app/utils	@utils/*	Custom utilities
src/app/config	@config/*	Configuration files for the application
src/media	@media/*	Media files such as images, videos, etc.