import React from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';


import { Route, Routes } from 'react-router-dom';
// Components
import Navbar from './app/components/layouts/Navbar/Navbar';
import Signup from './app/components/partials/Registration/Signup';
import Signin from './app/components/partials/Registration/Singin';

import Product from './app/components/partials/ProductPage/Product';
import  Checkout from './app/components/partials/Checkout/Checkout';
import ProductIndividual from './app/components/partials/ProductItem/ProductItem';
import SearchBar from './app/components/partials/ProductPage/Search';
// context providers
import { ProductsContextProvider } from './app/components/Contexts/ProductContext';
import { CartsContextProvider } from './app/components/Contexts/ShoppingCartContext';
import { NavbarContextProvider } from './app/components/Contexts/NavBarContext';
import { UserContextProvider } from './app/components/Contexts/UserContext';
import Footer from './app/components/layouts/Footer/Footer';
import PastOrders from './app/components/partials/PastOrders/PastOrders';

function App() {
  return (
    <div className="App">

      <UserContextProvider>
      <NavbarContextProvider>
      <ProductsContextProvider>
      <CartsContextProvider>

      <Navbar />
      <Routes>

        <Route
          path="/Signup"
          element={<Signup />}
        />

        <Route path="/Signin"
          element={<Signin />}
        />

        <Route path="/ProductsPage"
               element = {<Product />}
        />

        <Route path ="/product/:name/:id"
               element = {<ProductIndividual  />}
        />

        <Route path="/"
               element = {<SearchBar />}
        />

        <Route path="/ProductsPage" element = {<Product />}>
          <Route path=":id" element={<Product/>}></Route>
        </Route>

        <Route path="/Checkout"
               element = {<Checkout />}
        />

        <Route path = "/user/:id/orders"
               element = {<PastOrders />}
        />

        </Routes>

      </CartsContextProvider>
      </ProductsContextProvider>
      </NavbarContextProvider>
      </UserContextProvider>
      <Footer />
      
    </div>
  );
}

export default App;