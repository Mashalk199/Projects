package com.ecommerce.controller;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.util.ReflectionTestUtils;

import com.ecommerce.dto.AuthResponse;
import com.ecommerce.dto.LoginRequest;
import com.ecommerce.exceptions.EmailAlreadyExistsException;
import com.ecommerce.model.User;
import com.ecommerce.service.UserService;
import com.ecommerce.util.JwtUtils;

import jakarta.servlet.http.HttpServletRequest;

// Controller you will mock the relevant service and repoistory with mockito 
// You will then call certain service functions, check if they throw exceptions, 
// how many times they are called etc..

@SpringBootTest()
public class UserControllerTest {

    UserController controller;
    UserService service;
    BCryptPasswordEncoder passwordEncoder;
    JwtUtils jwtUtils;


    @BeforeEach
    void setup() {
        this.jwtUtils = mock(JwtUtils.class);
        this.passwordEncoder = mock(BCryptPasswordEncoder.class);
        this.service = mock(UserService.class);
        this.controller = new UserController(this.service);
        this.controller.setJwtUtils(this.jwtUtils);  // Inject the mocked JwtUtils into the controller

    }

    @Test
    void should_create_user_when_valid_user_provided(){

        // Based on a valid mock user the service was then called once..

        User mockedUser = new User("Parth", "Kulkarni", 
                          "jack@gmail.com", "somePassword", "someStreet"
                          , "Melbourne", "VIC", "3029", "Hoppers Crossing");

        this.controller.createUser(mockedUser);
        verify(this.service, times(1)).addUser(mockedUser);
    
    }

    @Test
    void should_not_create_user_when_email_already_exists() {
    
        // Given a user's signup request
        User signupUser = new User("Parth", "Kulkarni", 
                        "jack@gmail.com", "somePassword", "someStreet"
                        , "Melbourne", "VIC", "3029", "Hoppers Crossing");
        
        // Mock the behavior of the service to throw an EmailAlreadyExistsException when trying to add the user
        when(this.service.addUser(signupUser)).thenThrow(new EmailAlreadyExistsException("Email already exists!"));
        
        // Act
        ResponseEntity<?> response = this.controller.createUser(signupUser);
        
        // Assert
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Email already exists!", response.getBody());
        
        // Verify that the addUser method was called once
        verify(this.service, times(1)).addUser(signupUser);
    }


    @Test
    void should_login_user_when_correct_details_provided() {
        String email = "john@gmail.com";
        String rawPassword = "password123";
        String hashedPassword = "hashedPassword123";  // This is just a mock value; in reality, it would be BCrypt hash.
        
        User user = new User("John", "Doe", email, rawPassword, "123 St.", "City", "State", "12345", "Suburb");
        user.setPassword(hashedPassword);  // Set the hashed password
        
        // Define behavior for the mocked services and components
        when(this.service.login(user.getEmail(), user.getPassword())).thenReturn(user);
        when(this.service.checkPassword(rawPassword, hashedPassword)).thenReturn(true);
        when(this.jwtUtils.generateToken(user)).thenReturn("dummyToken");  // Mocked JWT token generation

        // Execute the login method
        LoginRequest request = new LoginRequest(user.getEmail(), user.getPassword());
        ResponseEntity<?> response = this.controller.loginUser(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }

    @Test
    void should_return_jwt_on_successful_login() {

        // Given a user's login request
        String email = "john@gmail.com";
        String rawPassword = "password123";
        String hashedPassword = "hashedPassword123";
        String mockToken = "mockedJwtToken";  // Mocked JWT token value
        
        User user = new User("John", "Doe", email, rawPassword, "123 St.", "City", "State", "12345", "Suburb");
        user.setPassword(hashedPassword);  // Set the hashed password
        
        when(this.service.login(email, hashedPassword)).thenReturn(user);
        when(this.service.checkPassword(rawPassword, hashedPassword)).thenReturn(true);
        when(this.jwtUtils.generateToken(user)).thenReturn(mockToken);
        
        // Act
        LoginRequest request = new LoginRequest(user.getEmail(), user.getPassword());
        ResponseEntity<?> response = this.controller.loginUser(request);
        
        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        
        verify(this.service, times(1)).login(email, hashedPassword);
        verify(this.jwtUtils, times(1)).generateToken(user);
    }

    @Test
    void should_return_user_data_for_valid_token() {

        String validToken = "validJwtToken";
        User mockUser = new User("John", "Doe", "john@gmail.com", "password123", "123 St.", "City", "State", "12345", "Suburb");

        // Mocking
        when(jwtUtils.validateToken(validToken)).thenReturn(true);
        when(jwtUtils.getUsernameFromToken(validToken)).thenReturn(mockUser.getEmail());
        when(service.emailExistsUser(mockUser.getEmail())).thenReturn(mockUser);

        // Mocking HttpServletRequest to return the valid token
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        when(mockRequest.getHeader("Authorization")).thenReturn("Bearer " + validToken);

        // Act
        ResponseEntity<?> response = controller.verifyTokenAndGetUserData(mockRequest);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockUser, response.getBody());
    }

    @Test
    void should_return_unauthorized_for_invalid_token() {

        String invalidToken = "invalidJwtToken";

        // Mocking
        when(jwtUtils.validateToken(invalidToken)).thenReturn(false);

        // Mocking HttpServletRequest to return the invalid token
        HttpServletRequest mockRequest = mock(HttpServletRequest.class);
        when(mockRequest.getHeader("Authorization")).thenReturn("Bearer " + invalidToken);

        // Act
        ResponseEntity<?> response = controller.verifyTokenAndGetUserData(mockRequest);

        // Assert
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals("Invalid or expired token", response.getBody());
    }


    @Test
    void should_return_bad_request_when_email_already_exists() {
        User existingUser = new User("John", "Doe", "john@gmail.com", "password123", "123 St.", "City", "State", "12345", "Suburb");
        when(service.addUser(existingUser)).thenThrow(new EmailAlreadyExistsException("Email already exists!"));

        ResponseEntity<?> response = controller.createUser(existingUser);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Email already exists!", response.getBody());
    }

    @Test
    void should_return_bad_request_when_login_details_are_incorrect() {
        String email = "john@gmail.com";
        String wrongPassword = "wrongPassword";

        when(service.login(email, wrongPassword)).thenReturn(null);

        LoginRequest request = new LoginRequest(email, wrongPassword);
        ResponseEntity<?> response = controller.loginUser(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

    @Test
    void should_return_bad_request_when_user_is_null() {

        User emptyUser = null;

        ResponseEntity<?> response = controller.createUser(emptyUser);

        // Assuming the service or controller does some validation on the fields and throws a custom exception or returns a bad request.
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }


    @Test
    void should_return_bad_request_when_user_fields_are_empty() {
        User emptyUser = new User("", "", "", "", "", "", "", "", "");

        when(this.service.addUser(emptyUser)).thenThrow(IllegalArgumentException.class);


        ResponseEntity<?> response = controller.createUser(emptyUser);

        // Assuming the service or controller does some validation on the fields and throws a custom exception or returns a bad request.
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }

        
}

