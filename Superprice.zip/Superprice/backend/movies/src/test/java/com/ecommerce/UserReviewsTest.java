package com.ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.model.UserReviews;
import com.ecommerce.repository.UserReviewsRepository;
import com.ecommerce.service.UserReviewService;

@SpringBootTest
public class UserReviewsTest {

    @MockBean
    private UserReviewsRepository userReviewsRepository;
    @Autowired
    private UserReviewService userReviewService;

    @Test
    void testSaveReviewWithLowestRating() {
        UserReviews mockReview = new UserReviews(new User(), new Product(), "Lowest Rating", 1);

        when(userReviewsRepository.save(mockReview)).thenReturn(mockReview);

        UserReviews savedReview = userReviewService.save(mockReview);

        assertNotNull(savedReview);
        assertEquals("Lowest Rating", savedReview.getContent());
        assertEquals(1, savedReview.getRating());
    }

    @Test
    void testSaveReviewWithHighestRating() {
        UserReviews mockReview = new UserReviews(new User(), new Product(), "Highest Rating", 5);

        when(userReviewsRepository.save(mockReview)).thenReturn(mockReview);

        UserReviews savedReview = userReviewService.save(mockReview);

        assertNotNull(savedReview);
        assertEquals("Highest Rating", savedReview.getContent());
        assertEquals(5, savedReview.getRating());
    }

    @Test
    void testSaveReviewWithEmptyContent() {
        UserReviews mockReview = new UserReviews(new User(), new Product(), "", 4);

        when(userReviewsRepository.save(mockReview)).thenReturn(mockReview);

        UserReviews savedReview = userReviewService.save(mockReview);

        assertNotNull(savedReview);
        assertEquals("", savedReview.getContent());
        assertEquals(4, savedReview.getRating());
    }


    @Test
    void testFindReviewsByProductId() {
        Long productId = 1L;

        // Mock a list of reviews for a product
        List<UserReviews> mockReviews = new ArrayList<>();
        mockReviews.add(new UserReviews(new User(), new Product(), "Review 1", 5));
        mockReviews.add(new UserReviews(new User(), new Product(), "Review 2", 4));

        when(userReviewsRepository.findReviewsByProductId(productId)).thenReturn(mockReviews);

        List<UserReviews> reviews = userReviewService.findByProductId(productId);

        // Verify that the service correctly retrieves reviews by product ID
        assertNotNull(reviews);
        assertEquals(2, reviews.size());
        assertEquals("Review 1", reviews.get(0).getContent());
        assertEquals("Review 2", reviews.get(1).getContent());
    }

    @Test
    void testSaveReview() {
        // Mock a review
        UserReviews mockReview = new UserReviews(new User(), new Product(), "New Review", 4);

        when(userReviewsRepository.save(mockReview)).thenReturn(mockReview);

        UserReviews savedReview = userReviewService.save(mockReview);

        // Verify that the service correctly saves a review
        assertNotNull(savedReview);
        assertEquals("New Review", savedReview.getContent());
        assertEquals(4, savedReview.getRating());
    }

    @Test
    void testSaveReviewWithNull() {
        // Mock a review with null values
        UserReviews mockReview = new UserReviews(null, null, null, 0);

        when(userReviewsRepository.save(mockReview)).thenReturn(null);

        UserReviews savedReview = userReviewService.save(mockReview);

        // Verify that the service handles saving a review with null values
        assertNull(savedReview);
    }


}

