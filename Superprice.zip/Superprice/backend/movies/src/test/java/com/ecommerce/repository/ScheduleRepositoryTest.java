package com.ecommerce.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.ecommerce.DataLoader;
import com.ecommerce.model.Schedule;

import jakarta.transaction.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;


@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class ScheduleRepositoryTest {

    
    @Autowired
    DataLoader dataLoader;

    @Autowired
    ScheduleRepository repo;

    
    @BeforeEach
        private void setUp() {
        dataLoader.run();
    }


    @AfterEach
    private void tearDown() {
        dataLoader.deleteAllData();
        repo.deleteAll();
    }


    @Test
    void findAll_should_contain_default_schedule(){

        var schedule = repo.findAll();

        assertEquals(14, schedule.size());

    }

    @Test
    void shouldFindScheduleById() {
        // Assuming a Schedule with ID 1 exists
        Optional<Schedule> retrievedSchedule = repo.findById(1L);
        assertTrue(retrievedSchedule.isPresent());
    }

    @Test
    void shouldNotFindNonExistentScheduleById() {
        // Fetch a Schedule with a non-existent ID
        Optional<Schedule> retrievedSchedule = repo.findById(9999L); // Assuming no Schedule has this ID
        assertFalse(retrievedSchedule.isPresent());
    }

 
    @Test
    @Transactional  // Helps keeps the session open
    void shouldSaveAndRetrieveSchedule() {

        // Create a new Schedule object
        Schedule schedule = new Schedule(new Date(), List.of("9:00 AM - 10:00 AM", "12:00 PM - 2:00 PM"));

        // Save the Schedule to the repository
        Schedule savedSchedule = repo.save(schedule);

        // Retrieve the saved Schedule by ID
        Optional<Schedule> retrievedSchedule = repo.findById(savedSchedule.getId());

        // Check if the retrieved Schedule matches the saved one
        assertTrue(retrievedSchedule.isPresent());
        
        // Compare the formatted date strings
        assertEquals(schedule.getAvailableTimeSlots(), retrievedSchedule.get().getAvailableTimeSlots());
    }

    // These test is not important to the functionality for us.. since we dont use them but its good to have FOR future extension:

    @Test
    void shouldDeleteSchedule() {
        // Assuming the Schedule with ID 2 exists before deletion

        // Delete the Schedule from the repository
        repo.deleteById(2L);

        // Attempt to retrieve the deleted Schedule by ID
        Optional<Schedule> retrievedSchedule = repo.findById(2L);

        // Check if the retrieved Schedule is empty after deletion
        assertFalse(retrievedSchedule.isPresent());
    }

}