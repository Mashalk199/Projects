package com.ecommerce.repository;

import com.ecommerce.DataLoader;
import com.ecommerce.model.Order;
import com.ecommerce.model.OrderProducts;
import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.service.OrderService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class OrderRepositoryTest {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private DataLoader dataLoader;

    @BeforeEach
    public void setUp() {
        dataLoader.deleteAllData();
        dataLoader.run();
    }

    @AfterEach
    public void tearDown() {
        orderRepository.deleteAll();
        dataLoader.deleteAllData();
    }

    @Test
    public void findAll_should_have_zero_orders_when_starts(){
        var orders = orderRepository.findAll();
        assertEquals(0, orders.size());
    }

    @Test
    public void findAll_should_have_one_order_when_one_is_added(){

        // In This test we will create some mocked products, orderProducts, user and order and save to that the db and see if that works

        Product p1 = new Product("Some Product", 15.20,"SomeCategory",
                    "SomeCategory", "SomeProductGroup", "SomeDesp", "SomeImg");
        p1 = productRepository.save(p1);  // Save the product first

        OrderProducts op1 = new OrderProducts();
        op1.setProduct(p1);

        User mockedUser = new User("MockedName", "MockedLastName", "mockedEmail", 
                        "mockedPassword", "mockedStreet", "mockedStreet", "mockedCity", 
                        "mockedPost", "mockedSuburb");
        mockedUser = userRepository.save(mockedUser);  // Save the user first

        Order order = new Order(50.00, List.of(op1), mockedUser);

        // This line here is added to ensure bi-direction
        op1.setOrder(order);

        orderRepository.save(order);

        var orders = orderRepository.findAll();
        assertEquals(1, orders.size());
    }

    @Test
    public void saveOrder_withNonExistentUser_shouldThrowException() {
        Product p1 = new Product("Test Product", 10.50,"TestCategory",
                        "TestSubCategory", "TestProductGroup", "TestDesp", "TestImg");
        p1 = productRepository.save(p1);  // Save the product first

        OrderProducts op1 = new OrderProducts();
        op1.setProduct(p1);

        // Create a user but don't save it to the repository
        User nonExistentUser = new User("NonExistentName", "NonExistentLastName", "nonExistentEmail", 
                            "nonExistentPassword", "nonExistentStreet", "nonExistentStreet", "nonExistentCity", 
                            "nonExistentPost", "nonExistentSuburb");

        Order order = new Order(10.50, List.of(op1), nonExistentUser);

        assertThrows(Exception.class, () -> orderRepository.save(order));  // Expect an exception to be thrown
    }

    @Test
    public void saveOrder_withNullUser_shouldThrowException() {
        Product product = new Product("Test Product", 10.50,"TestCategory",
                        "TestSubCategory", "TestProductGroup", "TestDesp", "TestImg");
        product = productRepository.save(product);  // Save the product

        OrderProducts op1 = new OrderProducts();
        op1.setProduct(product);

        Order order = new Order();
        order.setTotalCost(10.50);
        order.setOrderProducts(List.of(op1));
        order.setUser(null);

        assertThrows(Exception.class, () -> {
            orderRepository.save(order);
        });
    }


    @Test
    public void saveOrder_withLargeNumberOfProducts_shouldSaveCorrectly() {

        int numberOfProducts = 1000;  // This can be adjusted as per the maximum number you expect

        User user = new User("TestName", "TestLastName", "testEmail", 
                            "testPassword", "testStreet", "testStreet", "testCity", 
                            "testPost", "testSuburb");
        user = userRepository.save(user);  // Save the user first

        List<OrderProducts> orderProductsList = new ArrayList<>();
        for (int i = 0; i < numberOfProducts; i++) {
            Product product = new Product("Product " + i, 10.50,"TestCategory",
                        "TestSubCategory", "TestProductGroup", "TestDesp", "TestImg");
            product = productRepository.save(product);  // Save each product
            OrderProducts op = new OrderProducts();
            op.setProduct(product);
            orderProductsList.add(op);
        }

        
        Order order = new Order(numberOfProducts * 10, orderProductsList, user);
        
        // Set the reverse relationship for each OrderProducts
        for (OrderProducts op : orderProductsList) {
            op.setOrder(order);
        }

        order = orderRepository.save(order);

        assertNotNull(order);
        assertEquals(numberOfProducts, order.getOrderProducts().size());

       
    }

}