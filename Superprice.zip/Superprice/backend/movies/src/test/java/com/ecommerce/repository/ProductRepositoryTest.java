package com.ecommerce.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ecommerce.DataLoader;

@SpringBootTest
public class ProductRepositoryTest {

  @Autowired
  DataLoader dataLoader;

  @Autowired
  ProductRepository repo;

  @BeforeEach
  private void setUp() {
    dataLoader.deleteAllData();
    dataLoader.run();
  }

  @AfterEach
  private void tearDown() {
    dataLoader.deleteAllData();
  }

  @Test
  void findAll_should_haveDefaultValues_when_starts() {
    var products = repo.findAll();
    assertEquals(30, products.size());
  }

  @Test
  void findByID_should_returnEmpty_when_invalidIdIsProvided(){
    var optionalProduct = repo.findById(-1L);
    assertTrue(optionalProduct.isEmpty());
  }

  @Test
  void findByID_should_returnProduct_when_validIdIsProvided() {
    var firstProduct = repo.findAll().get(0);
    
    var optionalProduct = repo.findById(firstProduct.getId());
    assertTrue(optionalProduct.isPresent());
}


  @Test
  void filterProductsByCategory_shouldReturnTenProducts_when_validCategoryIsProvided() {
    var fruits = repo.customFindByCategory("Fruits");
    assertEquals(10, fruits.size());
  }

  @Test
  void filterProductsByCategory_shouldReturnEmptyList_when_invalidCategoryIsProvided() {
    var invalidCategory = repo.customFindByCategory("InvalidCategory");
    assertTrue(invalidCategory.isEmpty());
  }

  @Test
  void allCategories_shouldReturnCorrectNumberOfCategories() {
    var categories = repo.allCategories();
    assertEquals(5, categories.size());
  }

  @Test
  void getSubCategory_shouldReturnCorrectNumberOfProducts() {
    var apples = repo.getSubCategory("apples");
    assertEquals(5, apples.size());
  }

  @Test
  void getSubCategory_shouldReturnEmptyList_when_invalidSubCategoryIsProvided() {
    var invalidSubCategory = repo.getSubCategory("InvalidSubCategory");
    assertTrue(invalidSubCategory.isEmpty());
  }

}
