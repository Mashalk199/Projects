package com.ecommerce.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.ecommerce.DataLoader;
import com.ecommerce.model.User;

@SpringBootTest
public class UserRepositoryTest {

  @Autowired
  DataLoader dataLoader;

  @Autowired
  UserRepository repo;

  @BeforeEach
  private void setUp() {
    dataLoader.deleteAllData();
    dataLoader.run();
  }

  @AfterEach
  private void tearDown(){
    dataLoader.deleteAllData();
    repo.deleteAll();
  } 


  // First test application starts currently there should be zero users, that just how our implementation is...

  @Test
  void findAll_should_on_default_start_with_zero_users(){
    var users = repo.findAll();
    assertEquals(30, users.size());
 }

  @Test
  void findAll_should_update_when_user_is_added_size(){

    // Create a mock user, save it, and check the sizing..

    User mockedUser = new User("mockedFirstName", "mockedLastName", "mockedEmail", "mockedPassword", "mockedStreet",
                      "mockedCity", "mockedState", "mockedPostCode", "mockedSuburb");

    
    repo.save(mockedUser);

    var users = repo.findAll();
    assertEquals(31, users.size());

}

    @Test
    void findById_should_returnUser_when_Available() {

         // Create a mock user, save it, and check the sizing..

    User mockedUser = new User("TestFirstName", "TestLastName", "TestEmail", "TestPassword", "TestStreet",
                      "TestCity", "TestState", "TestPostCode", "TestSuburb");

    
    User savedMockedUser = repo.save(mockedUser);

    var user = repo.findById(savedMockedUser.getUserId());

    assertNotNull(user);
    assertEquals(savedMockedUser.getUserId(), user.get().getUserId());

    }

    @Test
    public void findByEmail_should_returnUser_when_emailExists() {

        
        User mockedUser = new User("TestFirstName", "TestLastName", "TestEmail@example.com", "TestPassword", "TestStreet",
                      "TestCity", "TestState", "TestPostCode", "TestSuburb");


        User savedMockedUser = repo.save(mockedUser);

        User foundUser = repo.findByEmail("TestEmail@example.com");
        assertNotNull(foundUser);
        assertEquals(savedMockedUser.getEmail(), foundUser.getEmail());
    }

    @Test
    public void findByEmail_should_returnNull_when_emailDoesNotExist() {
        User foundUser = repo.findByEmail("NonExistentEmail@example.com");
        assertNull(foundUser);
    }

    @Test
    public void deleteAll_should_removeAllUsers() {
        repo.deleteAll();
        assertEquals(0, repo.findAll().size());
    }

}
