package com.ecommerce.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.ecommerce.model.Product;
import com.ecommerce.service.ProductService;

@SpringBootTest
public class ProductControllerTest {

    ProductController controller;
    ProductService service;

    @BeforeEach
    void setup() {
        this.service = mock(ProductService.class);
        this.controller = new ProductController(this.service);  // Instantiate the controller and pass the mocked service
    }

    // Positive Tests
    @Test
    void testGetProductsPositive() {
        // Given
        Product product = new Product("Apple", 1.0, "Fruits", "Apple", "Fruit Group", "Delicious Apple", "image.jpg");
        when(service.getAllProducts()).thenReturn(Arrays.asList(product));

        // When
        List<Product> products = controller.getProducts();

        // Then
        assertFalse(products.isEmpty());
        assertEquals("Apple", products.get(0).getName());
    }

    @Test
    void testGetProductByIdPositive() {
        // Given
        Product product = new Product("Apple", 1.0, "Fruits", "Apple", "Fruit Group", "Delicious Apple", "image.jpg");
        when(service.getProductById(1L)).thenReturn(product);

        // When
        Product result = controller.getProductById(1L);

        // Then
        assertNotNull(result);
        assertEquals("Apple", result.getName());
    }

    // Negative Tests
    @Test
    void testGetProductsNegative() {
        // Given
        when(service.getAllProducts()).thenReturn(Collections.emptyList());

        // When
        List<Product> products = controller.getProducts();

        // Then
        assertTrue(products.isEmpty());
    }

    @Test
    void testGetProductByIdNegative() {
        // Given
        when(service.getProductById(1L)).thenReturn(null);

        // When
        Product result = controller.getProductById(1L);

        // Then
        assertNull(result);
    }

    // Boundary Tests ... assume we have we have a very large products list
    @Test
    void testGetProductsBoundary() {
        Product product = new Product("Apple", 1.0, "Fruits", "Apple", "Fruit Group", "Delicious Apple", "image.jpg");
        List<Product> productList = Collections.nCopies(1001, product);
        when(service.getAllProducts()).thenReturn(productList);

        // When
        List<Product> products = controller.getProducts();

        // Then
        assertEquals(1001, products.size());
        assertEquals("Apple", products.get(0).getName());
    }

    // Boundary Tests.. What if test with the boundary ID value which I believe is Long.MAX_VALUE
    @Test
    void testGetProductByIdBoundary() {
        // Given
        when(service.getProductById(Long.MAX_VALUE)).thenReturn(null);

        // When
        Product result = controller.getProductById(Long.MAX_VALUE);

        // Then
        assertNull(result);
    }


    // Boundary Test with null values
    @Test
    void testProductWithNullValues() {
        Product product = new Product(null, 5.0, null, null, null, null, null);
        when(service.getAllProducts()).thenReturn(Arrays.asList(product));

        // When
        List<Product> products = controller.getProducts();

        // Then
        assertFalse(products.isEmpty());
        assertNull(products.get(0).getName());
    }


    // Tests for getAllCategories

    // Positive Test
    @Test
    void testGetAllCategoriesPositive() {
        // Given
        when(service.allCategories()).thenReturn(Arrays.asList("Fruits", "Vegetables"));

        // When
        List<String> categories = controller.allCategories();

        // Then
        assertFalse(categories.isEmpty());
        assertTrue(categories.contains("Fruits"));
        assertTrue(categories.contains("Vegetables"));
    }

    // Negative Test
    @Test
    void testGetAllCategoriesNegative() {
        // Given
        when(service.allCategories()).thenReturn(Collections.emptyList());

        // When
        List<String> categories = controller.allCategories();

        // Then
        assertTrue(categories.isEmpty());
    }

    // Boundary Test with max categories
    @Test
    void testGetAllCategoriesBoundary() {
        List<String> maxCategories = Collections.nCopies(1000, "Category");
        when(service.allCategories()).thenReturn(maxCategories);

        // When
        List<String> categories = controller.allCategories();

        // Then
        assertEquals(1000, categories.size());
    }

    // Tests for getProductsByCategory

    // Positive Test
    @Test
    void testGetProductsByCategoryPositive() {
        // Given
        Product product = new Product("Apple", 1.0, "Fruits", "Apple", "Fruit Group", "Delicious Apple", "image.jpg");
        when(service.findByCategory("Fruits")).thenReturn(Arrays.asList(product));

        // When
        List<Product> products = controller.getProductsByCategory("Fruits");

        // Then
        assertFalse(products.isEmpty());
        assertEquals("Apple", products.get(0).getName());
    }

    // Negative Test
    @Test
    void testGetProductsByCategoryNegative() {
        // Given
        when(service.findByCategory("Unknown")).thenReturn(Collections.emptyList());

        // When
        List<Product> products = controller.getProductsByCategory("Unknown");

        // Then
        assertTrue(products.isEmpty());
    }

    // Boundary Test with max products in a category
    @Test
    void testGetProductsByCategoryBoundary() {
        // Given
        Product product = new Product("Apple", 1.0, "Fruits", "Apple", "Fruit Group", "Delicious Apple", "image.jpg");
        List<Product> maxProducts = Collections.nCopies(1001, product);
        when(service.findByCategory("Fruits")).thenReturn(maxProducts);

        // When
        List<Product> products = controller.getProductsByCategory("Fruits");

        // Then
        assertEquals(1001, products.size());
    }
}
