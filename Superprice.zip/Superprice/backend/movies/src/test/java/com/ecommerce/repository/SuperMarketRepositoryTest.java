package com.ecommerce.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Arrays;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.ecommerce.DataLoader;
import com.ecommerce.model.Product;
import com.ecommerce.model.Supermarket;

import jakarta.transaction.Transactional;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class SuperMarketRepositoryTest {

    @Autowired
    DataLoader dataLoader;

    @Autowired
    SupermarketRepository repo;

    
    @BeforeEach
        private void setUp() {
        dataLoader.deleteAllData();
        dataLoader.run();
    }


    @AfterEach
    private void tearDown() {
        dataLoader.deleteAllData();
        repo.deleteAll();
    }

    @Test
    void findAll_should_have_default_numb_of_stores_at_start(){

        var superMarkets = repo.findAll();
        assertEquals(5, superMarkets.size());
    }

    @Test
    void findAll_should_have_and_increase_size_after_adding_store(){

        Supermarket someMockedStore = new Supermarket();

        someMockedStore.setName("Mocked Name");
        someMockedStore.setLocation("Mocked Location");
        someMockedStore.setPostCode("Mocked PostCode");
        repo.save(someMockedStore);

        var superMarkets = repo.findAll();
        assertEquals(6, superMarkets.size());

        assertEquals(someMockedStore.getName(), superMarkets.get(5).getName());
    }

    @Test
    void deleteSupermarket_should_remove_supermarket_from_repo() {
        Supermarket supermarket = new Supermarket("Test Name", "Test Location", "Test PostCode");
        Supermarket savedSupermarket = repo.save(supermarket);

        repo.deleteById(savedSupermarket.getId());

        assertFalse(repo.existsById(savedSupermarket.getId()));
    }

    @Test
    void deleteNonExistentSupermarket() {
        Long nonExistentId = 9999L;  // Assuming this ID doesn't exist

        long countBeforeDelete = repo.count();
        repo.deleteById(nonExistentId);

        long countAfterDelete = repo.count();
        assertEquals(countBeforeDelete, countAfterDelete, "The count of supermarkets should remain the same after attempting to delete a non-existent supermarket.");
    }


    @Test
    void findSupermarketById_should_return_correct_supermarket() {
        Supermarket supermarket = new Supermarket("Test Name", "Test Location", "Test PostCode");
        Supermarket savedSupermarket = repo.save(supermarket);

        Supermarket fetchedSupermarket = repo.findById(savedSupermarket.getId()).orElse(null);

        assertNotNull(fetchedSupermarket);
        assertEquals(savedSupermarket.getName(), fetchedSupermarket.getName());
        assertEquals(savedSupermarket.getLocation(), fetchedSupermarket.getLocation());
        assertEquals(savedSupermarket.getPostCode(), fetchedSupermarket.getPostCode());
    }

    @Test
    void whenFetchingNonExistentSupermarket_thenExceptionShouldBeThrown() {
        
        Long nonExistentId = 9999L; // Assuming this ID doesn't exist in the test DB
        
        // Should throw an exception if ID does not exist..
        assertThrows(NoSuchElementException.class, () -> {
            repo.findById(nonExistentId).orElseThrow();
        });
    }

    @Test
    void saveSupermarket_withNull_shouldThrowException() {
        Supermarket supermarket = null;
        assertThrows(Exception.class, () -> {
            repo.save(supermarket);
        });
    }


}
