package com.ecommerce.controller;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderProducts;
import com.ecommerce.model.Product;
import com.ecommerce.model.User;
import com.ecommerce.service.OrderService;

import java.util.Arrays;
import java.util.Collections;
import java.util.Map;

@SpringBootTest
public class OrderControllerTest {

    private OrderController controller;
    private OrderService service;

    @BeforeEach
    void setup() {
        this.service = mock(OrderService.class);
        this.controller = new OrderController(this.service);
    }

    // Helper method to create a sample order
    private Order createSampleOrder() {
        User user = new User("Parth","Mashal", "mashal@gmail.com", 
                            "mashalPassword", "SomeStreet", "SomeCity", "someState", 
                            "somePost", "someSuburb");

        Product p1 = new Product("Coles Milk",2.5, "Dairy", "Milk", "Full-Cream", "Nice Milk", "image.jpg");
        Product p2 = new Product("Woolies Milk",2.5, "Dairy", "Milk", "Full-Cream", "Nice Milk", "image.jpg");


        OrderProducts op1 = new OrderProducts();
        op1.setProduct(p1);
        
        OrderProducts op2 = new OrderProducts();
        op2.setProduct(p2);

        return new Order(100.0, Arrays.asList(op1, op2), user);
    }

    // Positive Test
    @Test
    void testCreateOrderSuccessfully() {
        Order order = createSampleOrder();
        when(service.saveOrder(order)).thenReturn(order);

        ResponseEntity<?> response = controller.createOrder(order);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        
        Map<String, String> responseBody = (Map<String, String>) response.getBody();
        assertEquals("Order placed successfully!", responseBody.get("message"));

    }

    // Negative Test
    @Test
    void testCreateOrderWithNonExistentProduct() {
        Order order = createSampleOrder();
        when(service.saveOrder(order)).thenThrow(new RuntimeException("Product not found"));

        ResponseEntity<?> response = controller.createOrder(order);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("Product not found", response.getBody());
    }

    
    // Boundary Test lets say we add a lot of products... something like 100 is the backend capable of handling it
    @Test
    void testCreateOrderWithMaxProducts() {
        Order order = createSampleOrder();

        // Adding more products to the order to simulate boundary condition
        Product p4 = new Product("IGA Milk",3.5, "Dairy", "Milk", "Full-Cream", "Nice Milk", "image.jpg");

        OrderProducts opBoundary = new OrderProducts();
        opBoundary.setProduct(p4);

        order.setOrderProducts(Collections.nCopies(100, opBoundary));

        when(service.saveOrder(order)).thenReturn(order);

        ResponseEntity<?> response = controller.createOrder(order);

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        
        Map<String, String> responseBody = (Map<String, String>) response.getBody();
        assertEquals("Order placed successfully!", responseBody.get("message"));
    }

     // Boundary Test with null values
    @Test
     void testCreateOrderWithNullValues() {
         Order order = new Order();
         order.setUser(null);
 
         when(service.saveOrder(order)).thenThrow(new RuntimeException("Null values are not allowed"));
 
         ResponseEntity<?> response = controller.createOrder(order);
 
         assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
         assertEquals("Null values are not allowed", response.getBody());
     }

}