package com.ecommerce.controller;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import com.ecommerce.model.Schedule;
import com.ecommerce.service.ScheduleService;

@SpringBootTest
public class ScheduleControllerTest {

    private ScheduleController controller;
    private ScheduleService service;

    @BeforeEach
    void setup() {
        this.service = mock(ScheduleService.class);
        this.controller = new ScheduleController(service);
    }

    @Test
    void should_GetSchedule_ById() {
        long scheduleId = 1L;
        Schedule mockSchedule = new Schedule(new Date(), new ArrayList<>());
        when(service.getScheduleById(scheduleId)).thenReturn(Optional.of(mockSchedule));

        
        Optional<Schedule> response = controller.getScheduleById(scheduleId);

        
        Assertions.assertTrue(response.isPresent());
    }

    @Test
    void should_ReturnNotFound_When_ScheduleId_NotFound() {
        
        long scheduleId = 1L;
        when(service.getScheduleById(scheduleId)).thenReturn(Optional.empty());

        
        Optional<Schedule> response = controller.getScheduleById(scheduleId);

        
        Assertions.assertTrue(response.isEmpty());
    }

    @Test
    void should_GetAllSchedules() {
        List<Schedule> mockSchedules = new ArrayList<>();
        mockSchedules.add(new Schedule(new Date(), new ArrayList<>()));
        mockSchedules.add(new Schedule(new Date(), new ArrayList<>()));

        when(service.getAllSchedules()).thenReturn(mockSchedules);

        List<Schedule> response = controller.getAllSchedules();
        Assertions.assertEquals(mockSchedules.size(), response.size());

    }
    @Test
    void should_Get_Nothing_From_No_Schedules() {
        List<Schedule> mockSchedules = new ArrayList<>();

        when(service.getAllSchedules()).thenReturn(mockSchedules);

        List<Schedule> response = controller.getAllSchedules();
        Assertions.assertEquals(mockSchedules.size(), response.size());
        
    }

}
