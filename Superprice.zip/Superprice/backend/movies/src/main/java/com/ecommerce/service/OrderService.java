package com.ecommerce.service;

import com.ecommerce.model.Order;
import com.ecommerce.model.OrderProducts;
import com.ecommerce.model.Product;
import com.ecommerce.repository.OrderRepository;
import com.ecommerce.repository.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
   
    private final OrderRepository orderRepository;
    private final ProductRepository productRepository; // Add this

    @Autowired
    public OrderService(OrderRepository orderRepository, ProductRepository productRepository) { // Update this
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
    }

    // Business logic related to orders

    // Saves an order ensuring that the database bi-relationships are also met and satisfied
    public Order saveOrder(Order order) {        

        for(OrderProducts op : order.getOrderProducts()) {
            op.setOrder(order);
            
            // Use the transient productId to fetch the Product entity
            Product product = productRepository.findById(op.getProductId())
                      .orElseThrow(() -> new RuntimeException("Product not found")); 
            op.setProduct(product);
        }
    
        return orderRepository.save(order);
    }

    public List<Order> getUserOrders(Long id) {

        return orderRepository.findOrdersByUserId(id);

    }

}