package com.ecommerce.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Transient;

@Entity
public class OrderProducts {

    // Primary key for the OrderProducts table.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderProductId;

    // ManyToOne relationship: Many OrderProducts entries can belong to one Order.
    @ManyToOne
    @JoinColumn(name = "order_id", nullable = false)
    @JsonBackReference
    private Order order;

    // ManyToOne relationship: Many OrderProducts entries can relate to one Product.
    @ManyToOne
    @JoinColumn(name = "product_id", nullable = false)
    private Product product;

    // Default constructor.
    public OrderProducts(){};

    // Constructor to initialize the OrderProducts with the related Order, Product, and Product ID.
    public OrderProducts(Order order, Product product, Long productId) {
        this.order = order;
        this.product = product;
        this.productId = productId;
    }

    // Transient field, meaning it won't be persisted to the database.
    @Transient
    private Long productId;

    // Getter method for the product ID.
    public Long getProductId() {
        return productId;
    }

    // Setter method for the product ID.
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    // Getter method for the associated order.
    public Order getOrder() {
        return order;
    }

    // Setter method for the associated order.
    public void setOrder(Order order) {
        this.order = order;
    }

    // Getter method for the associated product.
    public Product getProduct() {
        return product;
    }

    // Setter method for the associated product.
    public void setProduct(Product product) {
        this.product = product;
    }
}
