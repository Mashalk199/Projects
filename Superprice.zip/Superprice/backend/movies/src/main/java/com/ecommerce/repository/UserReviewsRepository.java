package com.ecommerce.repository;

import com.ecommerce.model.UserReviews;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


@Repository
public interface UserReviewsRepository extends JpaRepository<UserReviews, Long>{

    // Write User Repository stuff here.
    
    @Query("SELECT r FROM user_reviews r WHERE r.product.id = :productId")
    List<UserReviews> findReviewsByProductId(@Param("productId") Long productId);



    


}

