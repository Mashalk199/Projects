package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.model.User;
import com.ecommerce.model.UserReviews;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserReviewService;


// This controller is used for managing reviews 
@RestController
@RequestMapping(path = "/api/review")
@CrossOrigin
public class UserReviewsController {

    // Used to save the reviews...
    // Declaration of the UserReview service
    private final UserReviewService userReviewsService;

       // Constructor injection for the product service.
    @Autowired
    public UserReviewsController(UserReviewService userReviewsService){
        this.userReviewsService = userReviewsService;
    }
    
    @GetMapping(path = "/{productId}/reviews")
    public ResponseEntity<List<UserReviews>> getReviewsForProduct(@PathVariable Long productId){
        List<UserReviews> reviews = this.userReviewsService.findByProductId(productId);
        return ResponseEntity.ok(reviews);
    }

    @PostMapping()
    public ResponseEntity<UserReviews> saveReviewForProduct(@RequestBody UserReviews reviews){

        try {
            UserReviews savedReview = this.userReviewsService.save(reviews);
            
            if(savedReview == null) {
                // If the saved review is null, then it wasn't created.
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            
            // If the review was successfully saved, return it with HTTP status 201 (Created).
            return new ResponseEntity<>(savedReview, HttpStatus.CREATED);
        } catch (Exception e) {
            // Handle any other exception that might occur.
            // This could be a more specific exception based on your service layer.
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    
    
}
