package com.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecommerce.model.Schedule;

public interface ScheduleRepository extends JpaRepository<Schedule, Long> {

    // Add custom methods here ...

}