package com.ecommerce.repository;

import com.ecommerce.model.Supermarket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface SupermarketRepository extends JpaRepository<Supermarket, Long> {


    // Returns supermarket object, by id
    @Query("SELECT s FROM Supermarket s WHERE s.supermarketId = :id")
    Supermarket getSupermarketById(Long id);

}
