package com.ecommerce.dto;

import com.ecommerce.model.User;

// DTO (Data Transfer Object) class for representing authentication responses.
public class AuthResponse {
    // User information.
    private User user;
    // JWT token associated with the authenticated user.
    private String jwtToken;

    // Constructor to initialize user information and JWT token.
    public AuthResponse(User user, String jwtToken) {
        this.user = user;
        this.jwtToken = jwtToken;
    }

    // Getters and setters for the class attributes.

    // Returns the user information.
    public User getUser() {
        return user;
    }

    // Sets the user information.
    public void setUser(User user) {
        this.user = user;
    }

    // Returns the JWT token.
    public String getJwtToken() {
        return jwtToken;
    }

    // Sets the JWT token.
    public void setJwtToken(String jwtToken) {
        this.jwtToken = jwtToken;
    }
}
