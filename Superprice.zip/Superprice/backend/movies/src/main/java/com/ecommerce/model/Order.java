package com.ecommerce.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity(name = "customerOrders")
public class Order {

    // Primary key for the Order table.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    // Field to store the total cost of the order.
    private double totalCost;

    // OneToMany relationship: One order can have many products.
    @OneToMany(mappedBy = "order", cascade = CascadeType.ALL)
    @JsonManagedReference
    private List<OrderProducts> orderProducts;

    // ManyToOne relationship: Many orders can belong to one user.
    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Date
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    private Date reviewDate = new Date();

    // Default constructor.
    public Order(){}

    // Constructor to initialise the Order with total cost, products, and the associated user.
    public Order(double totalCost, List<OrderProducts> orderProducts, User user) {
        this.totalCost = totalCost;
        this.orderProducts = orderProducts;
        this.user = user;
    }

    // Getter method for total cost.
    public double getTotalCost() {
        return totalCost;
    }

    // Setter method for total cost.
    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    // Getter method for the list of products in the order.
    public List<OrderProducts> getOrderProducts() {
        return orderProducts;
    }

    // Setter method for the list of products in the order.
    public void setOrderProducts(List<OrderProducts> orderProducts) {
        this.orderProducts = orderProducts;
    }

    // Getter method for the user associated with the order.
    public User getUser() {
        return user;
    }

    // Setter method for the user associated with the order.
    public void setUser(User user) {
        this.user = user;
    }
}
