package com.ecommerce.controller;

import com.ecommerce.model.Product;
import com.ecommerce.model.Supermarket;
import com.ecommerce.service.SupermarketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// Did not this test this component because it's not being used at all..

@RestController
@RequestMapping(path = "/api/supermarket")
@CrossOrigin
public class SupermarketController {
    @Autowired
    private SupermarketService supermarketService;


    // Retrieve Super market from supermarketId
    @GetMapping("/{id}")
    public Supermarket getSupermarketById(@PathVariable("id") Long id) {
        return supermarketService.getSupermarket(id);
    }

}
