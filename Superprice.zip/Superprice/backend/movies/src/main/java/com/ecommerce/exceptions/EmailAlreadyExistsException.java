package com.ecommerce.exceptions;

// Exception for when email already exists..

public class EmailAlreadyExistsException extends RuntimeException {
    
    public EmailAlreadyExistsException(String message) {
        super(message);
    }
}