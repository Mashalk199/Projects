package com.ecommerce.controller;

// Importing necessary libraries and dependencies.
import com.ecommerce.model.Order;
import com.ecommerce.service.OrderService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin
public class OrderController {

    // Autowiring the order service to this controller.
    @Autowired
    private OrderService orderService;

    // Constructor injection for order service.
    @Autowired
    public OrderController(OrderService orderService){
        this.orderService = orderService;
    }

    // Endpoint to create a new order.
    @PostMapping
    public ResponseEntity<?> createOrder(@RequestBody Order order) {
        try {
            // Logging the incoming request for debugging purposes.
            System.out.println("Received request to create order: " + order);
            // Saving the order using the order service.
            Order savedOrder = this.orderService.saveOrder(order);
            // Logging the success.
            System.out.println("Order successfully saved with ID: ");

            // Preparing a success response.
            Map<String, String> response = new HashMap<>();
            response.put("message", "Order placed successfully!");

            // Returning the success response.
            return new ResponseEntity<>(response, HttpStatus.CREATED);

        } catch (Exception e) {
            // Logging any errors during the process.
            System.out.println("Error occurred while saving the order: " + e);
            // Returning an error response.
            return new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    
    //Endpoint to get all orders of the user 
    @GetMapping("/user/{id}/orders")
    public ResponseEntity<?> getAllOrders(@PathVariable("id") Long id ){

        try{
            List<Order> userOrders = this.orderService.getUserOrders(id);

            return new ResponseEntity<>(userOrders, HttpStatus.OK);

        }

        catch (Exception e){
            return new ResponseEntity<>("Something has gone wrong", HttpStatus.INTERNAL_SERVER_ERROR);
        }


    }


}
