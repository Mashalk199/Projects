package com.ecommerce.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ecommerce.model.Schedule;
import com.ecommerce.service.ScheduleService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/checkout/schedules")
@CrossOrigin
public class ScheduleController {

    // Autowiring the ScheduleService into this controller.
    @Autowired
    private ScheduleService scheduleService;
    
    // Constructor injection for the ScheduleService.
    public ScheduleController(ScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    // Endpoint to fetch a specific schedule by its ID.
    @GetMapping("/{id}")
    public Optional<Schedule> getScheduleById(@PathVariable Long id) {
        return scheduleService.getScheduleById(id);
    }

    // Endpoint to fetch all available schedules.
    @GetMapping
    public List<Schedule> getAllSchedules() {
        return scheduleService.getAllSchedules();
    }

}