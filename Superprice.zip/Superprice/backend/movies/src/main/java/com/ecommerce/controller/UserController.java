package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.dto.AuthResponse;
import com.ecommerce.dto.LoginRequest;
import com.ecommerce.exceptions.EmailAlreadyExistsException;
import com.ecommerce.model.User;
import com.ecommerce.service.UserService;
import com.ecommerce.util.JwtUtils;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserController {

    // Autowiring the UserService and JwtUtils.
    @Autowired
    private UserService userService;

    // Constructor injection for the UserService.
    @Autowired
    public UserController(UserService userService){
        this.userService = userService;
    }

    @Autowired
    private JwtUtils jwtUtils;

    // Endpoint to create a new user.
    @PostMapping("/create")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        // Validate the incoming user object.
        if (user == null) {
            return new ResponseEntity<>("User data is missing", HttpStatus.BAD_REQUEST);
        }

        try {
            // Save the user and generate a JWT token.
            User savedUser = this.userService.addUser(user);
            String token = jwtUtils.generateToken(savedUser);

            System.out.println("Looking like something has gone wrong with jwtUtils");

            return new ResponseEntity<>(new AuthResponse(savedUser, token), HttpStatus.CREATED);
        } catch (EmailAlreadyExistsException e) {
            return new ResponseEntity<>("Email already exists!", HttpStatus.BAD_REQUEST);

        }catch (IllegalArgumentException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        
        } catch (Exception e) {
            e.printStackTrace();
          return new ResponseEntity<>("An error occurred while creating the user.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Add this method to inject the mocked JwtUtils for testing
      public void setJwtUtils(JwtUtils jwtUtils) {
        this.jwtUtils = jwtUtils;
    }
    
    // Endpoint to handle user login.
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody LoginRequest loginRequest) {
        try {
            System.out.println("Attempting to log in with email: " + loginRequest.getEmail());
            User authenticatedUser =  this.userService.login(loginRequest.getEmail(), loginRequest.getPassword());
            String token = jwtUtils.generateToken(authenticatedUser);

            if (authenticatedUser == null) {
                System.out.println("Login failed for email: " + loginRequest.getEmail());
                return new ResponseEntity<>("Invalid email or password", HttpStatus.BAD_REQUEST);
            }
    
            System.out.println("Login successful for email: " + loginRequest.getEmail());
            return new ResponseEntity<>(new AuthResponse(authenticatedUser, token), HttpStatus.OK);
    
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseEntity<>("An error occurred while trying to log in.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // Endpoint to verify the JWT token and fetch user data.
    @GetMapping("/verify")
    public ResponseEntity<?> verifyTokenAndGetUserData(HttpServletRequest request) {
        String token = request.getHeader("Authorization").substring(7);  // Assumes "Bearer <token>"
        
        if (token == null || !jwtUtils.validateToken(token)) {
            return new ResponseEntity<>("Invalid or expired token", HttpStatus.UNAUTHORIZED);
        }

        String userEmail = jwtUtils.getUsernameFromToken(token);
        User user =  this.userService.emailExistsUser(userEmail);  // Assuming you have this method in your UserService

        if (user == null) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
        
        return new ResponseEntity<>(user, HttpStatus.OK);
    }

}
