package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.repository.ScheduleRepository;
import com.ecommerce.model.Schedule;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleService {
    
    @Autowired
    private ScheduleRepository scheduleRepository;

    // Example method to retrieve a schedule by ID
    public Optional<Schedule> getScheduleById(Long scheduleId) {
        return scheduleRepository.findById(scheduleId);
    }

    // Example method to retrieve all schedules
    public List<Schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }
}