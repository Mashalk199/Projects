package com.ecommerce.model;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.transaction.Transactional;

@Entity
public class Supermarket {
    
    // Primary key for the Supermarket table.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long supermarketId;

    // OneToMany relationship: One supermarket can have many products.
    @OneToMany(mappedBy = "supermarket")
    private List<Product> products;

    // Attributes to store supermarket details.
    private String name;
    private String location; 
    private String postCode;

    // Default constructor.
    public Supermarket() { }

    // Constructor to initialise supermarket with name, location, and postcode.
    public Supermarket(String name, String location, String postCode) {
        this.name = name;
        this.location = location;
        this.postCode = postCode;
    }

    // Getter and Setter methods for the class attributes.

    // Getter method for the supermarket ID.
    public Long getId() {
        return supermarketId;
    }

    // Setter method for the supermarket ID.
    public void setId(Long id) {
        this.supermarketId = id;
    }

    // Getter method for the supermarket name.
    public String getName() {
        return name;
    }

    // Setter method for the supermarket name.
    public void setName(String name) {
        this.name = name;
    }

    // Getter method for the supermarket location.
    public String getLocation() {
        return location;
    }

    // Setter method for the supermarket location.
    public void setLocation(String location) {
        this.location = location;
    }

    // Getter method for the supermarket postcode.
    public String getPostCode() {
        return postCode;
    }

    // Setter method for the supermarket postcode.
    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }


}
