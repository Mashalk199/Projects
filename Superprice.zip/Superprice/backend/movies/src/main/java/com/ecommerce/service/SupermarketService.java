package com.ecommerce.service;

import com.ecommerce.model.Supermarket;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.SupermarketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SupermarketService {

    private SupermarketRepository supermarketRepository;

    @Autowired // Creates an instance/dependecny injection
    public SupermarketService(SupermarketRepository supermarketRepository){
        this.supermarketRepository = supermarketRepository;
    }

    // Returns supermarket object based on id..
    public Supermarket getSupermarket(Long id) {
        return this.supermarketRepository.getSupermarketById(id);
    }
}
