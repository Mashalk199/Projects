package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.ecommerce.exceptions.EmailAlreadyExistsException;
import com.ecommerce.model.User;
import com.ecommerce.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    public User addUser(User user) throws EmailAlreadyExistsException, IllegalArgumentException {

        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }
    
        if (user.getFirstName() == null || user.getFirstName().trim().isEmpty() || user.getFirstName().length() == 0) {
            throw new IllegalArgumentException("First name cannot be null or empty.");
        }
    
        if (user.getLastName() == null || user.getLastName().trim().isEmpty() || user.getLastName().length() == 0) {
            throw new IllegalArgumentException("Last name cannot be null or empty.");
        }
    
        if (user.getEmail() == null || user.getEmail().trim().isEmpty() || user.getEmail().length() == 0) {
            throw new IllegalArgumentException("Email cannot be null or empty.");
        }
    
        if (user.getPassword() == null || user.getPassword().trim().isEmpty() || user.getPassword().length() == 0) {
            throw new IllegalArgumentException("Password cannot be null or empty.");
        }
    
        if (user.getStreet() == null || user.getStreet().trim().isEmpty() || user.getStreet().length() == 0) {
            throw new IllegalArgumentException("Street cannot be null or empty.");
        }
    
        if (user.getCity() == null || user.getCity().trim().isEmpty() || user.getCity().length() == 0) {
            throw new IllegalArgumentException("City cannot be null or empty.");
        }
    
        if (user.getState() == null || user.getState().trim().isEmpty() || user.getState().length() == 0) {
            throw new IllegalArgumentException("State cannot be null or empty.");
        }
    
        if (user.getPostalCode() == null || user.getPostalCode().trim().isEmpty() || user.getPostalCode().length() == 0) {
            throw new IllegalArgumentException("Postal code cannot be null or empty.");
        }
    
        if (user.getSuburb() == null || user.getSuburb().trim().isEmpty() || user.getSuburb().length() == 0) {
            throw new IllegalArgumentException("Suburb cannot be null or empty.");
        }
    
        if (emailExists(user.getEmail())) {
            throw new EmailAlreadyExistsException("Email already exists!");
        }

        else{
            
        }
    
        user.setPassword(passwordEncoder.encode(user.getPassword()));
    
        return userRepository.save(user);
    }
    

    private boolean emailExists(String email) {
        return userRepository.findByEmail(email) != null;
    }

    public User emailExistsUser(String email) {
        return userRepository.findByEmail(email);
    }

    public boolean checkPassword(String rawPassword, String hashedPassword) {
        return passwordEncoder.matches(rawPassword, hashedPassword);
    }


    public User login(String email, String password) {
        User user = emailExistsUser(email);
        if (user != null && checkPassword(password, user.getPassword())) {
            return user;
        }
        return null;
    }

}