package com.ecommerce.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.ecommerce.model.UserReviews;
import com.ecommerce.repository.UserReviewsRepository;

@Service
public class UserReviewService {

    @Autowired
    private UserReviewsRepository userReviewsRepository;

    public List<UserReviews> findByProductId(Long productId) {
        return userReviewsRepository.findReviewsByProductId(productId);
    }

    public UserReviews save(UserReviews userReview) {
        return userReviewsRepository.save(userReview);
    }

}
