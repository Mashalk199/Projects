package com.ecommerce.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Product {

    // Primary key for the Product table.
    @Id
    @GeneratedValue
    private long id;

    // ManyToOne relationship: Many products can belong to one supermarket.
    @ManyToOne
    @JoinColumn(name = "supermarketId")
    private Supermarket supermarket;

    // Various attributes of the product.
    private String name; 
    private double price;
    private String productCategory; // Potential for a separate type or enum for product categories.
    private String subCategory;
    private String productGroup;
    private String productDescription;
    private String productImage;
    

    // Default constructor.
    public Product() { }

    // Parameterized constructor to initialize product attributes.
    public Product(String name, double price,  String productCategory, String subCategory, String productGroup, String productDescription, String productImage) {
        this.name = name;
        this.price = price;
        this.productCategory = productCategory;
        this.subCategory = productCategory;
        this.productGroup = productCategory;
        this.productDescription = productDescription;
        this.productImage = productImage;
    }

    // Getter and Setter methods for the class attributes.

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory;
    }

    public String getSubCategory() {
        return subCategory;
    }

    public void setSubCategory(String subCategory) {
        this.subCategory = subCategory;
    }

    public String getProductGroup() {
        return productGroup;
    }

    public void setProductGroup(String productGroup) {
        this.productGroup = productGroup;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
    
    public Supermarket getSupermarket() {
        return supermarket;
    }

    public void setSupermarket(Supermarket supermarket) {
        this.supermarket = supermarket;
    }

    public String getProductImage() {
        return productImage;
    }

    public void setProductImage(String productImage) {
        this.productImage = productImage;
    }
}
