package com.ecommerce.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
public class Schedule {

    // Primary key for the Schedule table.
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Attribute to store the date of the schedule.
    @Temporal(TemporalType.DATE)
    private Date date;

    // ElementCollection to store a list of timeslots for the schedule. 
    // This will create a separate table with a foreign key reference to the Schedule table.
    @ElementCollection
    @CollectionTable(name = "timeslots", joinColumns = @JoinColumn(name = "schedule_id"))
    @Column(name = "timeslot")
    private List<String> availableTimeSlots = new ArrayList<>();

    // Default constructor.
    public Schedule() {};

    // Constructor to initialise the schedule with a date and available timeslots.
    public Schedule(Date date, List<String> availableTimeSlots) {
        this.date = date;
        this.availableTimeSlots = availableTimeSlots;
    }

    // Getter method for the date.
    public Date getDate() {
        return date;
    }

    // Setter method for the date.
    public void setDate(Date date) {
        this.date = date;
    }

    // Getter method for the list of available timeslots.
    public List<String> getAvailableTimeSlots() {
        return availableTimeSlots;
    }

    // Setter method for the list of available timeslots.
    public void setAvailableTimeSlots(List<String> availableTimeSlots) {
        this.availableTimeSlots = availableTimeSlots;
    }

    // Getter method for the schedule ID.
    public Long getId() {
        return id;
    }
}
