package com.ecommerce.service;

import com.ecommerce.model.Product;
import com.ecommerce.repository.ProductRepository;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
   
    private final ProductRepository productRepository; 

    @Autowired // Creates an instance/dependecny injection
    public ProductService(ProductRepository productRepository){
        this.productRepository = productRepository;
    }
    // Business logic related to products


    // Retrieves all products
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // Retrieves products based on a certain category
    public List<Product> findByCategory(String productCategory) {
        return productRepository.customFindByCategory(productCategory);
    }

    public Product getProductById(Long id) {
        Optional<Product> product = productRepository.findById(id);
        return product.orElse(null);  // Return null if product is not found
    }

    // Retrieves all categories
    public List<String> allCategories() {
        return productRepository.allCategories();
    }

    // Retrieves products by subCategory
    public List<Product> getSubCategory(String subCategory) {
        return productRepository.getSubCategory(subCategory);
    }


}
