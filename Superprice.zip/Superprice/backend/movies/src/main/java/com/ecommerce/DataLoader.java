package com.ecommerce;

import com.ecommerce.model.Product;
import com.ecommerce.model.Schedule;
import com.ecommerce.model.Supermarket;
import com.ecommerce.model.User;
import com.ecommerce.model.UserReviews;
import com.ecommerce.repository.ProductRepository;
import com.ecommerce.repository.ScheduleRepository;
import com.ecommerce.repository.SupermarketRepository;
import com.ecommerce.repository.UserRepository;
import com.ecommerce.repository.UserReviewsRepository;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataLoader implements CommandLineRunner {

    private final SupermarketRepository supermarketRepository;
    private final ProductRepository productRepository;
    private final ScheduleRepository scheduleRepository;
    private final UserRepository userRepository;
    private final UserReviewsRepository userReviewsRepository;

    public DataLoader(SupermarketRepository supermarketRepository, 
                      ProductRepository productRepository,
                      ScheduleRepository scheduleRepository,
                      UserRepository userRepository,
                      UserReviewsRepository userReviewsRepository) {

        this.supermarketRepository = supermarketRepository;
        this.productRepository = productRepository;
        this.scheduleRepository = scheduleRepository;
        this.userRepository = userRepository;
        this.userReviewsRepository = userReviewsRepository;
    
    }

    @Override
    public void run(String... args) {
        // Create specific supermarkets
        Supermarket freshFoods = new Supermarket();
        freshFoods.setName("Fresh Foods");
        freshFoods.setLocation("Tarneit");
        freshFoods.setPostCode("3029");
        supermarketRepository.save(freshFoods);

        Supermarket healthyLiving = new Supermarket();
        healthyLiving.setName("Healthy Living");
        healthyLiving.setLocation("Werribee");
        healthyLiving.setPostCode("3030");
        supermarketRepository.save(healthyLiving);

        Supermarket quickMart = new Supermarket();
        quickMart.setName("Quick Mart");
        quickMart.setLocation("Wyndham Vale");
        quickMart.setPostCode("3291");
        supermarketRepository.save(quickMart);

        Supermarket organicHub = new Supermarket();
        organicHub.setName("Organic Hub");
        organicHub.setLocation("Melbourne");
        organicHub.setPostCode("3000");
        supermarketRepository.save(organicHub);

        Supermarket budgetStore = new Supermarket();
        budgetStore.setName("Budget Store");
        budgetStore.setLocation("Footscary");
        budgetStore.setPostCode("3401");
        supermarketRepository.save(budgetStore);


        // Apples, from many stores & different prices
        createAndSaveProduct(
            "Red Apples", 
            1.2, "Red and delicious apples", 
            "Fruits", 
            "apples", 
            "red", 
            freshFoods
        );

        createAndSaveProduct("Golden Apples", 1.5, "Golden and juicy apples", "Fruits", "apples", "golden", healthyLiving);
        createAndSaveProduct("Granny Smith Apples", 1.9, "Green, juicy, and refreshing apples", "Fruits", "apples", "granny smith", quickMart);
        createAndSaveProduct("Rome Beauty Apples", 2.2, "Beautiful and tasty Rome Apples", "Fruits", "apples", "rome", organicHub);
        createAndSaveProduct("Yellow Newton", 2.2, "Delicious Yellow Newton Apples", "Fruits", "apples", "yellow", budgetStore);



        // Fruits
        createAndSaveProduct("Pear", 1.2, "Fresh and juicy Pears", "Fruits", "FreshFoods", "Fruits", freshFoods);
        createAndSaveProduct("Banana", 0.8, "Sweet bananas", "Fruits", "FreshFoods", "Fruits", freshFoods);
        createAndSaveProduct("Orange", 1.0, "Citrus oranges", "Fruits", "FreshFoods", "Fruits", freshFoods);
        createAndSaveProduct("Grapes", 1.5, "Seedless grapes", "Fruits", "FreshFoods", "Fruits", freshFoods);
        createAndSaveProduct("Cherry", 2.0, "Red cherries", "Fruits", "FreshFoods", "Fruits", freshFoods);

        // Vegetables
        createAndSaveProduct("Carrot", 0.5, "Organic carrots", "Vegetables", "HealthyLiving", "Vegetables", healthyLiving);
        createAndSaveProduct("Broccoli", 1.1, "Fresh broccoli", "Vegetables", "HealthyLiving", "Vegetables", healthyLiving);
        createAndSaveProduct("Spinach", 0.9, "Baby spinach", "Vegetables", "HealthyLiving", "Vegetables", healthyLiving);
        createAndSaveProduct("Potato", 0.4, "Russet potatoes", "Vegetables", "HealthyLiving", "Vegetables", healthyLiving);
        createAndSaveProduct("Cucumber", 0.7, "Green cucumbers", "Vegetables", "HealthyLiving", "Vegetables", healthyLiving);

        // Dairy
        createAndSaveProduct("Milk", 2.0, "Organic milk", "Dairy", "QuickMart", "Dairy", quickMart);
        createAndSaveProduct("Cheese", 3.0, "Cheddar cheese", "Dairy", "QuickMart", "Dairy", quickMart);
        createAndSaveProduct("Yogurt", 1.2, "Greek yogurt", "Dairy", "QuickMart", "Dairy", quickMart);
        createAndSaveProduct("Butter", 2.5, "Salted butter", "Dairy", "QuickMart", "Dairy", quickMart);
        createAndSaveProduct("Cream", 1.8, "Heavy cream", "Dairy", "QuickMart", "Dairy", quickMart);

        // Grains
        createAndSaveProduct("Rice", 1.0, "Basmati rice", "Grains", "OrganicHub", "Grains", organicHub);
        createAndSaveProduct("Wheat Bread", 2.5, "Whole grain bread", "Grains", "OrganicHub", "Grains", organicHub);
        createAndSaveProduct("Oats", 1.3, "Rolled oats", "Grains", "OrganicHub", "Grains", organicHub);
        createAndSaveProduct("Pasta", 1.5, "Spaghetti pasta", "Grains", "OrganicHub", "Grains", organicHub);
        createAndSaveProduct("Cornmeal", 0.9, "Fine cornmeal", "Grains", "OrganicHub", "Grains", organicHub);

        // Meat
        createAndSaveProduct("Chicken", 5.0, "Organic chicken", "Meat", "BudgetStore", "Meat", budgetStore);
        createAndSaveProduct("Beef", 7.0, "Grass-fed beef", "Meat", "BudgetStore", "Meat", budgetStore);
        createAndSaveProduct("Pork", 6.0, "Organic pork", "Meat", "BudgetStore", "Meat", budgetStore);
        createAndSaveProduct("Fish", 8.0, "Fresh fish", "Meat", "BudgetStore", "Meat", budgetStore);
        createAndSaveProduct("Lamb", 9.0, "Grass-fed lamb", "Meat", "BudgetStore", "Meat", budgetStore);
    
        


        // List<Product> products = productRepository.customFindByCategory("Vegetables");
        
        // // Print to console
        // for (Product product : products) {
        //     System.out.println(product.getId());
        //     System.out.println(product.getName());
        //     System.out.println(product.getProductCategory());
        //     System.out.println(product.getProductDescription());
        //     System.out.println(product.getPrice());
        //     System.out.println("---");
        // }


        List<String> products = productRepository.allCategories();
        for (String product : products) {
            System.out.println(product);
        }

        // Create and save schedule entries for the next 7 days
        Calendar calendar = new GregorianCalendar();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm a");
        Date currentDate = new Date();

        for (int i = 0; i < 7; i++) {
            // Increment the date by one day
            calendar.setTime(currentDate);
            calendar.add(Calendar.DAY_OF_MONTH, i);
            Date scheduleDate = calendar.getTime();

            Schedule scheduleEntry = new Schedule();
            scheduleEntry.setDate(scheduleDate);

            // Add specific time slots to the schedule entry using an ArrayList
            List<String> timeSlots = new ArrayList<>();
            timeSlots.add("9:00 AM - 10:00 AM");
            timeSlots.add("12:00 PM - 2:00 PM");
            timeSlots.add("3:00 PM - 4:30 PM");
            // Add more time slots as needed

            scheduleEntry.setAvailableTimeSlots(timeSlots);

            scheduleRepository.save(scheduleEntry);

        }


    }

    private void createAndSaveProduct(String name, double price, String description, String category, String subCategory, String productGroup, Supermarket supermarket) {
        Product product = new Product();
        product.setName(name);
        product.setPrice(price);
        product.setProductDescription(description);
        product.setProductCategory(category);
        product.setSubCategory(subCategory);
        product.setProductGroup(productGroup);
        product.setSupermarket(supermarket);
        product.setProductImage("photo-1542838132-92c53300491e_hwso6x");
        productRepository.save(product);

        createAndSaveReview(product);

    }

    private void createAndSaveReview(Product product){

        // Make the users here

        User user = new User("Parth", "King", "something@gmail.com", "ayo", 
                            "mockStreet", "mockCity", "mockState", "mockPostCode", "mockSuburb");

        User savedUser = userRepository.save(user);

        UserReviews review = new UserReviews(savedUser, product, "This product is fantastic", 3); 

        userReviewsRepository.save(review);

    }

    public void deleteAllData() {
        
        
        // Delete all user reviews 
        userReviewsRepository.deleteAll();
        
        // Delete all products
        productRepository.deleteAll();
    
        // Delete all supermarkets
        supermarketRepository.deleteAll();
    
        // Delete all schedules
        scheduleRepository.deleteAll();

        // Delete all users
        userRepository.deleteAll();


    }


}