package com.ecommerce.controller;

// Importing necessary libraries and dependencies.
import com.ecommerce.model.Product;
import com.ecommerce.model.UserReviews;
import com.ecommerce.service.ProductService;
import com.ecommerce.service.UserReviewService;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(path = "/api/product")
@CrossOrigin
public class ProductController {
    
    // Declaration of the product service.
    private final ProductService productService;

    // Constructor injection for the product service.
    @Autowired
    public ProductController(ProductService productService){
        this.productService = productService;
    }

    // Endpoint to fetch all products.
    @GetMapping(path = "/all")
    public List<Product> getProducts() {
        return this.productService.getAllProducts();
    }

    // Endpoint to fetch products based on category.
    @GetMapping(path = "/byCategory/{productCategory}")
    public List<Product> getProductsByCategory(@PathVariable("productCategory") String productCategory) {
        return this.productService.findByCategory(productCategory);
    }

    // Endpoint to fetch a product based on its ID.
    @GetMapping(path = "/{id}")
    public Product getProductById(@PathVariable("id") Long id) {
        return this.productService.getProductById(id);
    }

    // Endpoint to fetch all product categories.
    @GetMapping(path = "/allCategories")
    public List<String> allCategories() {
        return this.productService.allCategories();
    }

    // Endpoint to fetch products based on sub-category.
    @GetMapping(path = "/bySubCategory/{subCategory}")
    public List<Product> bySubCategory(@PathVariable("subCategory") String subCategory) {
        return this.productService.getSubCategory(subCategory);
    }

}
