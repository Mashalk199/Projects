package com.ecommerce.dto;

// DTO (Data Transfer Object) class for representing user login requests.
public class LoginRequest {
    // User's email for authentication.
    private String email;
    // User's password for authentication.
    private String password;

    // Constructor to initialize email and password for the login request.
    public LoginRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // Returns the user's email.
    public String getEmail() {
        return this.email;
    }

    // Returns the user's password.
    public String getPassword() {
        return this.password;
    }
}
