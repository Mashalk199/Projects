    package com.ecommerce.model;

    import jakarta.persistence.Entity;
    import jakarta.persistence.FetchType;
    import jakarta.persistence.GeneratedValue;
    import jakarta.persistence.GenerationType;
    import jakarta.persistence.Id;
    import jakarta.persistence.ManyToOne;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.JoinColumn;

import java.util.Date;

import jakarta.persistence.Column;

    @Entity(name = "user_reviews")
    public class UserReviews {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long reviewId;

        @ManyToOne(fetch = FetchType.EAGER)
        @JoinColumn(name = "userId", nullable = false)
        private User user;

        @ManyToOne
        @JoinColumn(name = "productId", nullable = false)
        private Product product;

        @Column(nullable = false, length = 1000) // Assuming a max length for a review content.
        private String content;

        // For a rating out of 5, for instance.
        @Column(nullable = false)
        private int rating;

        // Date
        @Column(nullable = false)
        @Temporal(TemporalType.DATE)
        private Date reviewDate = new Date();

        // Default constructor
        public UserReviews() {}

        // Parameterized constructor
        public UserReviews(User user, Product product, String content, int rating) {
            this.user = user;
            this.product = product;
            this.content = content;
            this.rating = rating;
        }

        // Getters and Setters (with not null validation)
        public Long getId() {
            return reviewId;
        }

        public Long getUserId() {
            return user.getUserId();
        }

        public void setUserId(Long userId) {
            if (userId == null) {
                throw new IllegalArgumentException("UserId cannot be null.");
            }
            this.user.setUserId(userId);
        }

        public Long getProductId() {
            return product.getId();
        }

        public void setProductId(Long productId) {
            if (productId == null) {
                throw new IllegalArgumentException("ProductId cannot be null.");
            }
            this.product.setId(productId);
        }


        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            if (content == null) {
                throw new IllegalArgumentException("Content cannot be null.");
            }
            this.content = content;
        }

        public User getUser() {
            return user;
        }
        public Product getProduct() {
            return product;
        }

        public void setProduct(Product product) {
            this.product = product;
        }

        public int getRating() {
            return rating;
        }

        public void setRating(int rating) {
            this.rating = rating;
        }

        public Date getReviewDate() {
            return reviewDate;
        }

        public void setReviewDate(Date reviewDate) {
            this.reviewDate = reviewDate;
        }
    }
