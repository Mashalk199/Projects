NOTE: Due to some formatting issues when using Microsoft Teams editor, we have uploaded the corrupted images into a seperate directory named 'Images' under Milestone 3 docs. Apologies for this inconvenience.

# Git Hub Repo Link
https://github.com/cosc2299-sept-2023/team-project-group-p1-02

# Git Hub Repo Project Board Link
https://github.com/orgs/cosc2299-sept-2023/projects/125

# Team Name
Group P01-02 (Friday 4.30 PM Class)

# Links
1) Natnael Gizaw - https://rmiteduau-my.sharepoint.com/personal/s3897250_student_rmit_edu_au/_layouts/15/stream.aspx?id=%2Fpersonal%2Fs3897250%5Fstudent%5Frmit%5Fedu%5Fau%2FDocuments%2F2023%2D10%2D08%2021%2D11%2D17%2Emkv&referrer=OfficeHome%2EWeb&referrerScenario=RecentVideo%2EView
2) Christopher Lamb - https://rmiteduau-my.sharepoint.com/:v:/r/personal/s3945643_student_rmit_edu_au/Documents/Recording-20231008_215806.webm?csf=1&web=1&e=3smOhS&nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZyIsInJlZmVycmFsQXBwUGxhdGZvcm0iOiJXZWIiLCJyZWZlcnJhbE1vZGUiOiJ2aWV3In19
3) Parth Kulkarni (s3897572) - https://rmiteduau-my.sharepoint.com/:v:/g/personal/s3897572_student_rmit_edu_au/Ee87MzIVk7ZOmWNxLhtZq30BtvzN7mZLecErT1TkN9yTLg?nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZyIsInJlZmVycmFsQXBwUGxhdGZvcm0iOiJXZWIiLCJyZWZlcnJhbE1vZGUiOiJ2aWV3In19&e=Y1AbWS
4) Ethan Christos Makiri (s3899376) - https://rmiteduau-my.sharepoint.com/:v:/g/personal/s3899376_student_rmit_edu_au/EanbwLcdr0hOnM2jhocgHRIBlPPVcGwZqElGnOZPS8RQPg?nav=eyJyZWZlcnJhbEluZm8iOnsicmVmZXJyYWxBcHAiOiJTdHJlYW1XZWJBcHAiLCJyZWZlcnJhbFZpZXciOiJTaGFyZURpYWxvZyIsInJlZmVycmFsQXBwUGxhdGZvcm0iOiJXZWIiLCJyZWZlcnJhbE1vZGUiOiJ2aWV3In19&e=dIwJE8