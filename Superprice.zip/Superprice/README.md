# team-project-group-p1-02
team-project-group-p1-02 created by GitHub Classroom

# How to run (Front End)
1) Cd into the frontend folder
2) run the command npm install (These will install the npm dependencies) we used in our project.
3) run the command npm start... this should create a react app on port 3000. Please ensure you this and only this port
   
# How to run (Back End)
1) cd/visually navigate into the backend/movies folder
2) Find the ShopApplication.Java File and run that
3) This will create a server on port 8080, please only use this port
4) To access the H2 Database type in your URL Search bar localhost:8080/h2-console
5) The password is just "password".

# Docker commands (local containerization)
### Back-end
1) docker build --platform linux/amd64 -t rmitsept/backend .
2) docker run --platform linux/amd64 -p 8080:8080 rmitsept/backend

### Front-end
3) docker build --platform linux/amd64 -t rmitsept/frontend .
4) docker run --platform linux/amd64 -p 3000:3000 -e API_URL="http://172.17.0.2:8080 rmitsept/frontend

### Docker Compose (whole project)
5) docker-compose build 
6) docker-compose up
7) docker-compose -f docker-compose-mysql.yml --env-file compose-vars.env up

### Uploading Images to ECR
front-end: 324353116250.dkr.ecr.us-east-1.amazonaws.com/major-project-front-end-sql
back-end: 324353116250.dkr.ecr.us-east-1.amazonaws.com/major-project-backend

Steps to deploy docker images:
##### Configure aws credentials
aws configure

##### Set environment variable
set REPO=324353116250.dkr.ecr.us-east-1.amazonaws.com/major-project-front-end-sql
or
set REPO=324353116250.dkr.ecr.us-east-1.amazonaws.com/major-project-backend


##### Build image
docker build --platform linux/amd64 -t %REPO% .

##### Log in ECR with docker
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin %REPO%

##### Push image to ECR
docker push %REPO%

##### Elastic Bean Stalk Link For Application
http://super-price-mysql-env-env.eba-p2f5iqjp.us-east-1.elasticbeanstalk.com/

##### Access Back End Server For Application 
http://super-price-mysql-env-env.eba-p2f5iqjp.us-east-1.elasticbeanstalk.com:8080

##### Access Adminer For Application
http://super-price-mysql-env-env.eba-p2f5iqjp.us-east-1.elasticbeanstalk.com:9000
Service Name: database
user: root
password: password
database: superdatabase


# Created By
Parth Kulkarni, Ethan Makiri, Mashal Khan, Christopher Lamb and Natnael Gizaw.
    
   

